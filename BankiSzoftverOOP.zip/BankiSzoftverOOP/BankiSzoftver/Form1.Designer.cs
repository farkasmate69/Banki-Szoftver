﻿namespace BankiSzoftver
{

    partial class Form1
    {

        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {

            if (disposing && (components != null))

            {

                components.Dispose();

            }

            base.Dispose(disposing);

        }

        #region Windows Form Designer generated code

        private void InitializeComponent()

        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabDisplay = new System.Windows.Forms.TabPage();
            this.groupDisplay = new System.Windows.Forms.GroupBox();
            this.listCustomers = new System.Windows.Forms.ListBox();
            this.listInvoices = new System.Windows.Forms.ListBox();
            this.listTransactions = new System.Windows.Forms.ListBox();
            this.tabUjUgyfel = new System.Windows.Forms.TabPage();
            this.groupUjUgyfel = new System.Windows.Forms.GroupBox();
            this.lblNev = new System.Windows.Forms.Label();
            this.lblLakcim = new System.Windows.Forms.Label();
            this.lblSzuletesiDatum = new System.Windows.Forms.Label();
            this.lblTelefonszam = new System.Windows.Forms.Label();
            this.txtNev = new System.Windows.Forms.TextBox();
            this.txtLakcim = new System.Windows.Forms.TextBox();
            this.dtSzuletesiDatum = new System.Windows.Forms.DateTimePicker();
            this.txtTelefonszam = new System.Windows.Forms.TextBox();
            this.btnMentesUgyfel = new System.Windows.Forms.Button();
            this.tabSzamlaszam = new System.Windows.Forms.TabPage();
            this.groupSzamlaszam = new System.Windows.Forms.GroupBox();
            this.lblUgyfelValasztas = new System.Windows.Forms.Label();
            this.cmbUgyfel = new System.Windows.Forms.ComboBox();
            this.lblSzamlaszam = new System.Windows.Forms.Label();
            this.lblSzamlatipus = new System.Windows.Forms.Label();
            this.lblAktualisEgyenleg = new System.Windows.Forms.Label();
            this.lblSzamlanyitasDatuma = new System.Windows.Forms.Label();
            this.txtSzamlaszam = new System.Windows.Forms.TextBox();
            this.cmbSzamlatipus = new System.Windows.Forms.ComboBox();
            this.txtAktualisEgyenleg = new System.Windows.Forms.TextBox();
            this.dtSzamlanyitasDatuma = new System.Windows.Forms.DateTimePicker();
            this.btnMentesSzamla = new System.Windows.Forms.Button();
            this.tabTranzakcio = new System.Windows.Forms.TabPage();
            this.groupTranzakcio = new System.Windows.Forms.GroupBox();
            this.lblSzamlaValasztas = new System.Windows.Forms.Label();
            this.cmbSzamla = new System.Windows.Forms.ComboBox();
            this.lblErintettSzamlaszam = new System.Windows.Forms.Label();
            this.lblTipus = new System.Windows.Forms.Label();
            this.lblOsszeg = new System.Windows.Forms.Label();
            this.lblDatum = new System.Windows.Forms.Label();
            this.txtErintettSzamlaszam = new System.Windows.Forms.TextBox();
            this.txtTipus = new System.Windows.Forms.TextBox();
            this.txtOsszeg = new System.Windows.Forms.TextBox();
            this.dtTranzakcioDatum = new System.Windows.Forms.DateTimePicker();
            this.btnMentesTranzakcio = new System.Windows.Forms.Button();
            this.tabFilter = new System.Windows.Forms.TabPage();
            this.groupFilters = new System.Windows.Forms.GroupBox();
            this.lblFilterUgyfelNeve = new System.Windows.Forms.Label();
            this.txtFilterCustomer = new System.Windows.Forms.TextBox();
            this.btnFilterCustomer = new System.Windows.Forms.Button();
            this.lblFilterSzamlaKeresese = new System.Windows.Forms.Label();
            this.txtFilterInvoice = new System.Windows.Forms.TextBox();
            this.btnFilterInvoice = new System.Windows.Forms.Button();
            this.lblFilterTranzakciokIdopont = new System.Windows.Forms.Label();
            this.dtFilterTransactionDate = new System.Windows.Forms.DateTimePicker();
            this.btnFilterTransactionDate = new System.Windows.Forms.Button();
            this.listFilterResults = new System.Windows.Forms.ListBox();
            this.tabSpecial = new System.Windows.Forms.TabPage();
            this.groupSpecialQueries = new System.Windows.Forms.GroupBox();
            this.btnNegativeBalance = new System.Windows.Forms.Button();
            this.btnTopCustomer = new System.Windows.Forms.Button();
            this.lblSpecialAdottIdoszak = new System.Windows.Forms.Label();
            this.lblSpecialKezdoDatum = new System.Windows.Forms.Label();
            this.lblSpecialVegDatum = new System.Windows.Forms.Label();
            this.dtDailyTransactionDate = new System.Windows.Forms.DateTimePicker();
            this.dtDailyTransactionDateEnd = new System.Windows.Forms.DateTimePicker();
            this.btnDailyTransactionSummary = new System.Windows.Forms.Button();
            this.listSpecialResults = new System.Windows.Forms.ListBox();
            this.tabOther = new System.Windows.Forms.TabPage();
            this.groupOtherFunctions = new System.Windows.Forms.GroupBox();
            this.lblOtherOsszesBefizetesKivetel = new System.Windows.Forms.Label();
            this.lblOtherKezdoDatum = new System.Windows.Forms.Label();
            this.lblOtherVegDatum = new System.Windows.Forms.Label();
            this.dtStatisticsDate = new System.Windows.Forms.DateTimePicker();
            this.dtStatisticsDateEnd = new System.Windows.Forms.DateTimePicker();
            this.btnStatistics = new System.Windows.Forms.Button();
            this.btnExport = new System.Windows.Forms.Button();
            this.btnBackup = new System.Windows.Forms.Button();
            this.btnRestore = new System.Windows.Forms.Button();
            this.listOtherResults = new System.Windows.Forms.ListBox();
            this.tabControl1.SuspendLayout();
            this.tabDisplay.SuspendLayout();
            this.groupDisplay.SuspendLayout();
            this.tabUjUgyfel.SuspendLayout();
            this.groupUjUgyfel.SuspendLayout();
            this.tabSzamlaszam.SuspendLayout();
            this.groupSzamlaszam.SuspendLayout();
            this.tabTranzakcio.SuspendLayout();
            this.groupTranzakcio.SuspendLayout();
            this.tabFilter.SuspendLayout();
            this.groupFilters.SuspendLayout();
            this.tabSpecial.SuspendLayout();
            this.groupSpecialQueries.SuspendLayout();
            this.tabOther.SuspendLayout();
            this.groupOtherFunctions.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabDisplay);
            this.tabControl1.Controls.Add(this.tabUjUgyfel);
            this.tabControl1.Controls.Add(this.tabSzamlaszam);
            this.tabControl1.Controls.Add(this.tabTranzakcio);
            this.tabControl1.Controls.Add(this.tabFilter);
            this.tabControl1.Controls.Add(this.tabSpecial);
            this.tabControl1.Controls.Add(this.tabOther);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(800, 450);
            this.tabControl1.TabIndex = 0;
            // 
            // tabDisplay
            // 
            this.tabDisplay.Controls.Add(this.groupDisplay);
            this.tabDisplay.Location = new System.Drawing.Point(4, 22);
            this.tabDisplay.Name = "tabDisplay";
            this.tabDisplay.Size = new System.Drawing.Size(792, 424);
            this.tabDisplay.TabIndex = 0;
            this.tabDisplay.Text = "Megjelenítés";
            // 
            // groupDisplay
            // 
            this.groupDisplay.Controls.Add(this.listCustomers);
            this.groupDisplay.Controls.Add(this.listInvoices);
            this.groupDisplay.Controls.Add(this.listTransactions);
            this.groupDisplay.Location = new System.Drawing.Point(20, 20);
            this.groupDisplay.Name = "groupDisplay";
            this.groupDisplay.Size = new System.Drawing.Size(740, 360);
            this.groupDisplay.TabIndex = 0;
            this.groupDisplay.TabStop = false;
            this.groupDisplay.Text = "Listák";
            // 
            // listCustomers
            // 
            this.listCustomers.FormattingEnabled = true;
            this.listCustomers.HorizontalScrollbar = true;
            this.listCustomers.Location = new System.Drawing.Point(20, 30);
            this.listCustomers.Name = "listCustomers";
            this.listCustomers.Size = new System.Drawing.Size(200, 290);
            this.listCustomers.TabIndex = 0;
            // 
            // listInvoices
            // 
            this.listInvoices.FormattingEnabled = true;
            this.listInvoices.HorizontalScrollbar = true;
            this.listInvoices.Location = new System.Drawing.Point(260, 30);
            this.listInvoices.Name = "listInvoices";
            this.listInvoices.Size = new System.Drawing.Size(200, 290);
            this.listInvoices.TabIndex = 1;
            // 
            // listTransactions
            // 
            this.listTransactions.FormattingEnabled = true;
            this.listTransactions.HorizontalScrollbar = true;
            this.listTransactions.Location = new System.Drawing.Point(500, 30);
            this.listTransactions.Name = "listTransactions";
            this.listTransactions.Size = new System.Drawing.Size(200, 290);
            this.listTransactions.TabIndex = 2;
            // 
            // tabUjUgyfel
            // 
            this.tabUjUgyfel.Controls.Add(this.groupUjUgyfel);
            this.tabUjUgyfel.Location = new System.Drawing.Point(4, 22);
            this.tabUjUgyfel.Name = "tabUjUgyfel";
            this.tabUjUgyfel.Size = new System.Drawing.Size(792, 424);
            this.tabUjUgyfel.TabIndex = 1;
            this.tabUjUgyfel.Text = "Új ügyfél";
            // 
            // groupUjUgyfel
            // 
            this.groupUjUgyfel.Controls.Add(this.lblNev);
            this.groupUjUgyfel.Controls.Add(this.lblLakcim);
            this.groupUjUgyfel.Controls.Add(this.lblSzuletesiDatum);
            this.groupUjUgyfel.Controls.Add(this.lblTelefonszam);
            this.groupUjUgyfel.Controls.Add(this.txtNev);
            this.groupUjUgyfel.Controls.Add(this.txtLakcim);
            this.groupUjUgyfel.Controls.Add(this.dtSzuletesiDatum);
            this.groupUjUgyfel.Controls.Add(this.txtTelefonszam);
            this.groupUjUgyfel.Controls.Add(this.btnMentesUgyfel);
            this.groupUjUgyfel.Location = new System.Drawing.Point(20, 20);
            this.groupUjUgyfel.Name = "groupUjUgyfel";
            this.groupUjUgyfel.Size = new System.Drawing.Size(740, 360);
            this.groupUjUgyfel.TabIndex = 0;
            this.groupUjUgyfel.TabStop = false;
            this.groupUjUgyfel.Text = "Új ügyfél";
            // 
            // lblNev
            // 
            this.lblNev.Location = new System.Drawing.Point(30, 30);
            this.lblNev.Name = "lblNev";
            this.lblNev.Size = new System.Drawing.Size(200, 15);
            this.lblNev.TabIndex = 0;
            this.lblNev.Text = "Név";
            // 
            // lblLakcim
            // 
            this.lblLakcim.Location = new System.Drawing.Point(30, 80);
            this.lblLakcim.Name = "lblLakcim";
            this.lblLakcim.Size = new System.Drawing.Size(200, 15);
            this.lblLakcim.TabIndex = 1;
            this.lblLakcim.Text = "Lakcím";
            // 
            // lblSzuletesiDatum
            // 
            this.lblSzuletesiDatum.Location = new System.Drawing.Point(30, 130);
            this.lblSzuletesiDatum.Name = "lblSzuletesiDatum";
            this.lblSzuletesiDatum.Size = new System.Drawing.Size(200, 15);
            this.lblSzuletesiDatum.TabIndex = 2;
            this.lblSzuletesiDatum.Text = "Születési dátum";
            // 
            // lblTelefonszam
            // 
            this.lblTelefonszam.Location = new System.Drawing.Point(30, 180);
            this.lblTelefonszam.Name = "lblTelefonszam";
            this.lblTelefonszam.Size = new System.Drawing.Size(200, 15);
            this.lblTelefonszam.TabIndex = 3;
            this.lblTelefonszam.Text = "Telefonszám";
            // 
            // txtNev
            // 
            this.txtNev.Location = new System.Drawing.Point(30, 50);
            this.txtNev.Name = "txtNev";
            this.txtNev.Size = new System.Drawing.Size(300, 20);
            this.txtNev.TabIndex = 4;
            // 
            // txtLakcim
            // 
            this.txtLakcim.Location = new System.Drawing.Point(30, 100);
            this.txtLakcim.Name = "txtLakcim";
            this.txtLakcim.Size = new System.Drawing.Size(300, 20);
            this.txtLakcim.TabIndex = 5;
            // 
            // dtSzuletesiDatum
            // 
            this.dtSzuletesiDatum.Location = new System.Drawing.Point(30, 150);
            this.dtSzuletesiDatum.Name = "dtSzuletesiDatum";
            this.dtSzuletesiDatum.Size = new System.Drawing.Size(300, 20);
            this.dtSzuletesiDatum.TabIndex = 6;
            // 
            // txtTelefonszam
            // 
            this.txtTelefonszam.Location = new System.Drawing.Point(30, 200);
            this.txtTelefonszam.Name = "txtTelefonszam";
            this.txtTelefonszam.Size = new System.Drawing.Size(300, 20);
            this.txtTelefonszam.TabIndex = 7;
            // 
            // btnMentesUgyfel
            // 
            this.btnMentesUgyfel.Location = new System.Drawing.Point(399, 37);
            this.btnMentesUgyfel.Name = "btnMentesUgyfel";
            this.btnMentesUgyfel.Size = new System.Drawing.Size(300, 58);
            this.btnMentesUgyfel.TabIndex = 8;
            this.btnMentesUgyfel.Text = "Mentés";
            this.btnMentesUgyfel.Click += new System.EventHandler(this.btnMentesUgyfel_Click);
            // 
            // tabSzamlaszam
            // 
            this.tabSzamlaszam.Controls.Add(this.groupSzamlaszam);
            this.tabSzamlaszam.Location = new System.Drawing.Point(4, 22);
            this.tabSzamlaszam.Name = "tabSzamlaszam";
            this.tabSzamlaszam.Size = new System.Drawing.Size(792, 424);
            this.tabSzamlaszam.TabIndex = 2;
            this.tabSzamlaszam.Text = "Számlaszám";
            // 
            // groupSzamlaszam
            // 
            this.groupSzamlaszam.Controls.Add(this.lblUgyfelValasztas);
            this.groupSzamlaszam.Controls.Add(this.cmbUgyfel);
            this.groupSzamlaszam.Controls.Add(this.lblSzamlaszam);
            this.groupSzamlaszam.Controls.Add(this.lblSzamlatipus);
            this.groupSzamlaszam.Controls.Add(this.lblAktualisEgyenleg);
            this.groupSzamlaszam.Controls.Add(this.lblSzamlanyitasDatuma);
            this.groupSzamlaszam.Controls.Add(this.txtSzamlaszam);
            this.groupSzamlaszam.Controls.Add(this.cmbSzamlatipus);
            this.groupSzamlaszam.Controls.Add(this.txtAktualisEgyenleg);
            this.groupSzamlaszam.Controls.Add(this.dtSzamlanyitasDatuma);
            this.groupSzamlaszam.Controls.Add(this.btnMentesSzamla);
            this.groupSzamlaszam.Location = new System.Drawing.Point(20, 20);
            this.groupSzamlaszam.Name = "groupSzamlaszam";
            this.groupSzamlaszam.Size = new System.Drawing.Size(740, 360);
            this.groupSzamlaszam.TabIndex = 0;
            this.groupSzamlaszam.TabStop = false;
            this.groupSzamlaszam.Text = "Számlaszám";
            // 
            // lblUgyfelValasztas
            // 
            this.lblUgyfelValasztas.Location = new System.Drawing.Point(30, 30);
            this.lblUgyfelValasztas.Name = "lblUgyfelValasztas";
            this.lblUgyfelValasztas.Size = new System.Drawing.Size(200, 15);
            this.lblUgyfelValasztas.TabIndex = 0;
            this.lblUgyfelValasztas.Text = "Ügyfél kiválasztása";
            // 
            // cmbUgyfel
            // 
            this.cmbUgyfel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbUgyfel.FormattingEnabled = true;
            this.cmbUgyfel.Location = new System.Drawing.Point(30, 50);
            this.cmbUgyfel.Name = "cmbUgyfel";
            this.cmbUgyfel.Size = new System.Drawing.Size(300, 21);
            this.cmbUgyfel.TabIndex = 1;
            // 
            // lblSzamlaszam
            // 
            this.lblSzamlaszam.Location = new System.Drawing.Point(30, 90);
            this.lblSzamlaszam.Name = "lblSzamlaszam";
            this.lblSzamlaszam.Size = new System.Drawing.Size(200, 15);
            this.lblSzamlaszam.TabIndex = 2;
            this.lblSzamlaszam.Text = "Számlaszám";
            // 
            // lblSzamlatipus
            // 
            this.lblSzamlatipus.Location = new System.Drawing.Point(30, 140);
            this.lblSzamlatipus.Name = "lblSzamlatipus";
            this.lblSzamlatipus.Size = new System.Drawing.Size(200, 15);
            this.lblSzamlatipus.TabIndex = 3;
            this.lblSzamlatipus.Text = "Számlatípus";
            // 
            // lblAktualisEgyenleg
            // 
            this.lblAktualisEgyenleg.Location = new System.Drawing.Point(30, 190);
            this.lblAktualisEgyenleg.Name = "lblAktualisEgyenleg";
            this.lblAktualisEgyenleg.Size = new System.Drawing.Size(200, 15);
            this.lblAktualisEgyenleg.TabIndex = 4;
            this.lblAktualisEgyenleg.Text = "Aktuális egyenleg";
            // 
            // lblSzamlanyitasDatuma
            // 
            this.lblSzamlanyitasDatuma.Location = new System.Drawing.Point(30, 240);
            this.lblSzamlanyitasDatuma.Name = "lblSzamlanyitasDatuma";
            this.lblSzamlanyitasDatuma.Size = new System.Drawing.Size(200, 15);
            this.lblSzamlanyitasDatuma.TabIndex = 5;
            this.lblSzamlanyitasDatuma.Text = "Számlanyitás dátuma";
            // 
            // txtSzamlaszam
            // 
            this.txtSzamlaszam.Location = new System.Drawing.Point(30, 110);
            this.txtSzamlaszam.Name = "txtSzamlaszam";
            this.txtSzamlaszam.Size = new System.Drawing.Size(300, 20);
            this.txtSzamlaszam.TabIndex = 6;
            // 
            // cmbSzamlatipus
            // 
            this.cmbSzamlatipus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSzamlatipus.FormattingEnabled = true;
            this.cmbSzamlatipus.Items.AddRange(new object[] {
            "folyószámla",
            "megtakarítási számla"});
            this.cmbSzamlatipus.Location = new System.Drawing.Point(30, 160);
            this.cmbSzamlatipus.Name = "cmbSzamlatipus";
            this.cmbSzamlatipus.Size = new System.Drawing.Size(300, 21);
            this.cmbSzamlatipus.TabIndex = 7;
            // 
            // txtAktualisEgyenleg
            // 
            this.txtAktualisEgyenleg.Location = new System.Drawing.Point(30, 210);
            this.txtAktualisEgyenleg.Name = "txtAktualisEgyenleg";
            this.txtAktualisEgyenleg.Size = new System.Drawing.Size(300, 20);
            this.txtAktualisEgyenleg.TabIndex = 8;
            // 
            // dtSzamlanyitasDatuma
            // 
            this.dtSzamlanyitasDatuma.Location = new System.Drawing.Point(30, 260);
            this.dtSzamlanyitasDatuma.Name = "dtSzamlanyitasDatuma";
            this.dtSzamlanyitasDatuma.Size = new System.Drawing.Size(300, 20);
            this.dtSzamlanyitasDatuma.TabIndex = 9;
            // 
            // btnMentesSzamla
            // 
            this.btnMentesSzamla.Location = new System.Drawing.Point(415, 30);
            this.btnMentesSzamla.Name = "btnMentesSzamla";
            this.btnMentesSzamla.Size = new System.Drawing.Size(282, 61);
            this.btnMentesSzamla.TabIndex = 10;
            this.btnMentesSzamla.Text = "Mentés";
            this.btnMentesSzamla.Click += new System.EventHandler(this.btnMentesSzamla_Click);
            // 
            // tabTranzakcio
            // 
            this.tabTranzakcio.Controls.Add(this.groupTranzakcio);
            this.tabTranzakcio.Location = new System.Drawing.Point(4, 22);
            this.tabTranzakcio.Name = "tabTranzakcio";
            this.tabTranzakcio.Size = new System.Drawing.Size(792, 424);
            this.tabTranzakcio.TabIndex = 3;
            this.tabTranzakcio.Text = "Tranzakció";
            // 
            // groupTranzakcio
            // 
            this.groupTranzakcio.Controls.Add(this.lblSzamlaValasztas);
            this.groupTranzakcio.Controls.Add(this.cmbSzamla);
            this.groupTranzakcio.Controls.Add(this.lblErintettSzamlaszam);
            this.groupTranzakcio.Controls.Add(this.lblTipus);
            this.groupTranzakcio.Controls.Add(this.lblOsszeg);
            this.groupTranzakcio.Controls.Add(this.lblDatum);
            this.groupTranzakcio.Controls.Add(this.txtErintettSzamlaszam);
            this.groupTranzakcio.Controls.Add(this.txtTipus);
            this.groupTranzakcio.Controls.Add(this.txtOsszeg);
            this.groupTranzakcio.Controls.Add(this.dtTranzakcioDatum);
            this.groupTranzakcio.Controls.Add(this.btnMentesTranzakcio);
            this.groupTranzakcio.Location = new System.Drawing.Point(20, 20);
            this.groupTranzakcio.Name = "groupTranzakcio";
            this.groupTranzakcio.Size = new System.Drawing.Size(740, 360);
            this.groupTranzakcio.TabIndex = 0;
            this.groupTranzakcio.TabStop = false;
            this.groupTranzakcio.Text = "Tranzakció";
            // 
            // lblSzamlaValasztas
            // 
            this.lblSzamlaValasztas.Location = new System.Drawing.Point(30, 30);
            this.lblSzamlaValasztas.Name = "lblSzamlaValasztas";
            this.lblSzamlaValasztas.Size = new System.Drawing.Size(200, 15);
            this.lblSzamlaValasztas.TabIndex = 0;
            this.lblSzamlaValasztas.Text = "Számla kiválasztása";
            // 
            // cmbSzamla
            // 
            this.cmbSzamla.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSzamla.FormattingEnabled = true;
            this.cmbSzamla.Location = new System.Drawing.Point(30, 50);
            this.cmbSzamla.Name = "cmbSzamla";
            this.cmbSzamla.Size = new System.Drawing.Size(300, 21);
            this.cmbSzamla.TabIndex = 1;
            // 
            // lblErintettSzamlaszam
            // 
            this.lblErintettSzamlaszam.Location = new System.Drawing.Point(30, 90);
            this.lblErintettSzamlaszam.Name = "lblErintettSzamlaszam";
            this.lblErintettSzamlaszam.Size = new System.Drawing.Size(200, 15);
            this.lblErintettSzamlaszam.TabIndex = 2;
            this.lblErintettSzamlaszam.Text = "Érintett számlaszám";
            // 
            // lblTipus
            // 
            this.lblTipus.Location = new System.Drawing.Point(30, 140);
            this.lblTipus.Name = "lblTipus";
            this.lblTipus.Size = new System.Drawing.Size(200, 15);
            this.lblTipus.TabIndex = 3;
            this.lblTipus.Text = "Típus";
            // 
            // lblOsszeg
            // 
            this.lblOsszeg.Location = new System.Drawing.Point(30, 190);
            this.lblOsszeg.Name = "lblOsszeg";
            this.lblOsszeg.Size = new System.Drawing.Size(200, 15);
            this.lblOsszeg.TabIndex = 4;
            this.lblOsszeg.Text = "Összeg";
            // 
            // lblDatum
            // 
            this.lblDatum.Location = new System.Drawing.Point(30, 240);
            this.lblDatum.Name = "lblDatum";
            this.lblDatum.Size = new System.Drawing.Size(200, 15);
            this.lblDatum.TabIndex = 5;
            this.lblDatum.Text = "Dátum";
            // 
            // txtErintettSzamlaszam
            // 
            this.txtErintettSzamlaszam.Location = new System.Drawing.Point(30, 110);
            this.txtErintettSzamlaszam.Name = "txtErintettSzamlaszam";
            this.txtErintettSzamlaszam.Size = new System.Drawing.Size(300, 20);
            this.txtErintettSzamlaszam.TabIndex = 6;
            // 
            // txtTipus
            // 
            this.txtTipus.Location = new System.Drawing.Point(30, 160);
            this.txtTipus.Name = "txtTipus";
            this.txtTipus.Size = new System.Drawing.Size(300, 20);
            this.txtTipus.TabIndex = 7;
            // 
            // txtOsszeg
            // 
            this.txtOsszeg.Location = new System.Drawing.Point(30, 210);
            this.txtOsszeg.Name = "txtOsszeg";
            this.txtOsszeg.Size = new System.Drawing.Size(300, 20);
            this.txtOsszeg.TabIndex = 8;
            // 
            // dtTranzakcioDatum
            // 
            this.dtTranzakcioDatum.Location = new System.Drawing.Point(30, 260);
            this.dtTranzakcioDatum.Name = "dtTranzakcioDatum";
            this.dtTranzakcioDatum.Size = new System.Drawing.Size(300, 20);
            this.dtTranzakcioDatum.TabIndex = 9;
            // 
            // btnMentesTranzakcio
            // 
            this.btnMentesTranzakcio.Location = new System.Drawing.Point(399, 30);
            this.btnMentesTranzakcio.Name = "btnMentesTranzakcio";
            this.btnMentesTranzakcio.Size = new System.Drawing.Size(298, 64);
            this.btnMentesTranzakcio.TabIndex = 10;
            this.btnMentesTranzakcio.Text = "Mentés";
            this.btnMentesTranzakcio.Click += new System.EventHandler(this.btnMentesTranzakcio_Click);
            // 
            // tabFilter
            // 
            this.tabFilter.Controls.Add(this.groupFilters);
            this.tabFilter.Location = new System.Drawing.Point(4, 22);
            this.tabFilter.Name = "tabFilter";
            this.tabFilter.Size = new System.Drawing.Size(792, 424);
            this.tabFilter.TabIndex = 4;
            this.tabFilter.Text = "Szűrés";
            // 
            // groupFilters
            // 
            this.groupFilters.Controls.Add(this.lblFilterUgyfelNeve);
            this.groupFilters.Controls.Add(this.txtFilterCustomer);
            this.groupFilters.Controls.Add(this.btnFilterCustomer);
            this.groupFilters.Controls.Add(this.lblFilterSzamlaKeresese);
            this.groupFilters.Controls.Add(this.txtFilterInvoice);
            this.groupFilters.Controls.Add(this.btnFilterInvoice);
            this.groupFilters.Controls.Add(this.lblFilterTranzakciokIdopont);
            this.groupFilters.Controls.Add(this.dtFilterTransactionDate);
            this.groupFilters.Controls.Add(this.btnFilterTransactionDate);
            this.groupFilters.Controls.Add(this.listFilterResults);
            this.groupFilters.Location = new System.Drawing.Point(20, 20);
            this.groupFilters.Name = "groupFilters";
            this.groupFilters.Size = new System.Drawing.Size(740, 360);
            this.groupFilters.TabIndex = 0;
            this.groupFilters.TabStop = false;
            this.groupFilters.Text = "Szűrési lehetőségek";
            // 
            // lblFilterUgyfelNeve
            // 
            this.lblFilterUgyfelNeve.Location = new System.Drawing.Point(14, 73);
            this.lblFilterUgyfelNeve.Name = "lblFilterUgyfelNeve";
            this.lblFilterUgyfelNeve.Size = new System.Drawing.Size(150, 15);
            this.lblFilterUgyfelNeve.TabIndex = 0;
            this.lblFilterUgyfelNeve.Text = "Ügyfél neve";
            // 
            // txtFilterCustomer
            // 
            this.txtFilterCustomer.Location = new System.Drawing.Point(14, 93);
            this.txtFilterCustomer.Name = "txtFilterCustomer";
            this.txtFilterCustomer.Size = new System.Drawing.Size(150, 20);
            this.txtFilterCustomer.TabIndex = 0;
            // 
            // btnFilterCustomer
            // 
            this.btnFilterCustomer.Location = new System.Drawing.Point(174, 93);
            this.btnFilterCustomer.Name = "btnFilterCustomer";
            this.btnFilterCustomer.Size = new System.Drawing.Size(70, 23);
            this.btnFilterCustomer.TabIndex = 1;
            this.btnFilterCustomer.Text = "Keresés";
            this.btnFilterCustomer.Click += new System.EventHandler(this.btnFilterCustomer_Click);
            // 
            // lblFilterSzamlaKeresese
            // 
            this.lblFilterSzamlaKeresese.Location = new System.Drawing.Point(14, 151);
            this.lblFilterSzamlaKeresese.Name = "lblFilterSzamlaKeresese";
            this.lblFilterSzamlaKeresese.Size = new System.Drawing.Size(150, 15);
            this.lblFilterSzamlaKeresese.TabIndex = 2;
            this.lblFilterSzamlaKeresese.Text = "Számla keresése";
            // 
            // txtFilterInvoice
            // 
            this.txtFilterInvoice.Location = new System.Drawing.Point(14, 171);
            this.txtFilterInvoice.Name = "txtFilterInvoice";
            this.txtFilterInvoice.Size = new System.Drawing.Size(150, 20);
            this.txtFilterInvoice.TabIndex = 2;
            // 
            // btnFilterInvoice
            // 
            this.btnFilterInvoice.Location = new System.Drawing.Point(174, 171);
            this.btnFilterInvoice.Name = "btnFilterInvoice";
            this.btnFilterInvoice.Size = new System.Drawing.Size(70, 23);
            this.btnFilterInvoice.TabIndex = 3;
            this.btnFilterInvoice.Text = "Keresés";
            this.btnFilterInvoice.Click += new System.EventHandler(this.btnFilterInvoice_Click);
            // 
            // lblFilterTranzakciokIdopont
            // 
            this.lblFilterTranzakciokIdopont.Location = new System.Drawing.Point(14, 227);
            this.lblFilterTranzakciokIdopont.Name = "lblFilterTranzakciokIdopont";
            this.lblFilterTranzakciokIdopont.Size = new System.Drawing.Size(200, 15);
            this.lblFilterTranzakciokIdopont.TabIndex = 4;
            this.lblFilterTranzakciokIdopont.Text = "Tranzakciók ebben az időpontban";
            // 
            // dtFilterTransactionDate
            // 
            this.dtFilterTransactionDate.Location = new System.Drawing.Point(14, 247);
            this.dtFilterTransactionDate.Name = "dtFilterTransactionDate";
            this.dtFilterTransactionDate.Size = new System.Drawing.Size(150, 20);
            this.dtFilterTransactionDate.TabIndex = 5;
            // 
            // btnFilterTransactionDate
            // 
            this.btnFilterTransactionDate.Location = new System.Drawing.Point(174, 247);
            this.btnFilterTransactionDate.Name = "btnFilterTransactionDate";
            this.btnFilterTransactionDate.Size = new System.Drawing.Size(70, 23);
            this.btnFilterTransactionDate.TabIndex = 6;
            this.btnFilterTransactionDate.Text = "Keresés";
            this.btnFilterTransactionDate.Click += new System.EventHandler(this.btnFilterTransactionDate_Click);
            // 
            // listFilterResults
            // 
            this.listFilterResults.Location = new System.Drawing.Point(260, 40);
            this.listFilterResults.Name = "listFilterResults";
            this.listFilterResults.Size = new System.Drawing.Size(450, 290);
            this.listFilterResults.TabIndex = 7;
            // 
            // tabSpecial
            // 
            this.tabSpecial.Controls.Add(this.groupSpecialQueries);
            this.tabSpecial.Location = new System.Drawing.Point(4, 22);
            this.tabSpecial.Name = "tabSpecial";
            this.tabSpecial.Size = new System.Drawing.Size(792, 424);
            this.tabSpecial.TabIndex = 5;
            this.tabSpecial.Text = "Speciális lekérdezések";
            // 
            // groupSpecialQueries
            // 
            this.groupSpecialQueries.Controls.Add(this.btnNegativeBalance);
            this.groupSpecialQueries.Controls.Add(this.btnTopCustomer);
            this.groupSpecialQueries.Controls.Add(this.lblSpecialAdottIdoszak);
            this.groupSpecialQueries.Controls.Add(this.lblSpecialKezdoDatum);
            this.groupSpecialQueries.Controls.Add(this.lblSpecialVegDatum);
            this.groupSpecialQueries.Controls.Add(this.dtDailyTransactionDate);
            this.groupSpecialQueries.Controls.Add(this.dtDailyTransactionDateEnd);
            this.groupSpecialQueries.Controls.Add(this.btnDailyTransactionSummary);
            this.groupSpecialQueries.Controls.Add(this.listSpecialResults);
            this.groupSpecialQueries.Location = new System.Drawing.Point(20, 20);
            this.groupSpecialQueries.Name = "groupSpecialQueries";
            this.groupSpecialQueries.Size = new System.Drawing.Size(740, 360);
            this.groupSpecialQueries.TabIndex = 0;
            this.groupSpecialQueries.TabStop = false;
            this.groupSpecialQueries.Text = "Lekérdezések";
            // 
            // btnNegativeBalance
            // 
            this.btnNegativeBalance.Location = new System.Drawing.Point(20, 40);
            this.btnNegativeBalance.Name = "btnNegativeBalance";
            this.btnNegativeBalance.Size = new System.Drawing.Size(200, 23);
            this.btnNegativeBalance.TabIndex = 0;
            this.btnNegativeBalance.Text = "Túlköltések";
            this.btnNegativeBalance.Click += new System.EventHandler(this.btnNegativeBalance_Click);
            // 
            // btnTopCustomer
            // 
            this.btnTopCustomer.Location = new System.Drawing.Point(20, 76);
            this.btnTopCustomer.Name = "btnTopCustomer";
            this.btnTopCustomer.Size = new System.Drawing.Size(200, 23);
            this.btnTopCustomer.TabIndex = 2;
            this.btnTopCustomer.Text = "Legnagyobb forgalmú ügyfél";
            this.btnTopCustomer.Click += new System.EventHandler(this.btnTopCustomer_Click);
            // 
            // lblSpecialAdottIdoszak
            // 
            this.lblSpecialAdottIdoszak.Location = new System.Drawing.Point(20, 118);
            this.lblSpecialAdottIdoszak.Name = "lblSpecialAdottIdoszak";
            this.lblSpecialAdottIdoszak.Size = new System.Drawing.Size(200, 15);
            this.lblSpecialAdottIdoszak.TabIndex = 3;
            this.lblSpecialAdottIdoszak.Text = "Adott időszak tranzakciói";
            // 
            // lblSpecialKezdoDatum
            // 
            this.lblSpecialKezdoDatum.Location = new System.Drawing.Point(20, 136);
            this.lblSpecialKezdoDatum.Name = "lblSpecialKezdoDatum";
            this.lblSpecialKezdoDatum.Size = new System.Drawing.Size(100, 15);
            this.lblSpecialKezdoDatum.TabIndex = 4;
            this.lblSpecialKezdoDatum.Text = "Kezdő dátum:";
            // 
            // lblSpecialVegDatum
            // 
            this.lblSpecialVegDatum.Location = new System.Drawing.Point(20, 162);
            this.lblSpecialVegDatum.Name = "lblSpecialVegDatum";
            this.lblSpecialVegDatum.Size = new System.Drawing.Size(100, 15);
            this.lblSpecialVegDatum.TabIndex = 5;
            this.lblSpecialVegDatum.Text = "Vég dátum:";
            // 
            // dtDailyTransactionDate
            // 
            this.dtDailyTransactionDate.Location = new System.Drawing.Point(120, 136);
            this.dtDailyTransactionDate.Name = "dtDailyTransactionDate";
            this.dtDailyTransactionDate.Size = new System.Drawing.Size(150, 20);
            this.dtDailyTransactionDate.TabIndex = 6;
            // 
            // dtDailyTransactionDateEnd
            // 
            this.dtDailyTransactionDateEnd.Location = new System.Drawing.Point(120, 162);
            this.dtDailyTransactionDateEnd.Name = "dtDailyTransactionDateEnd";
            this.dtDailyTransactionDateEnd.Size = new System.Drawing.Size(150, 20);
            this.dtDailyTransactionDateEnd.TabIndex = 7;
            // 
            // btnDailyTransactionSummary
            // 
            this.btnDailyTransactionSummary.Location = new System.Drawing.Point(280, 136);
            this.btnDailyTransactionSummary.Name = "btnDailyTransactionSummary";
            this.btnDailyTransactionSummary.Size = new System.Drawing.Size(70, 46);
            this.btnDailyTransactionSummary.TabIndex = 8;
            this.btnDailyTransactionSummary.Text = "Keresés";
            this.btnDailyTransactionSummary.Click += new System.EventHandler(this.btnDailyTransactionSummary_Click);
            // 
            // listSpecialResults
            // 
            this.listSpecialResults.Location = new System.Drawing.Point(356, 40);
            this.listSpecialResults.Name = "listSpecialResults";
            this.listSpecialResults.Size = new System.Drawing.Size(354, 290);
            this.listSpecialResults.TabIndex = 6;
            // 
            // tabOther
            // 
            this.tabOther.Controls.Add(this.groupOtherFunctions);
            this.tabOther.Location = new System.Drawing.Point(4, 22);
            this.tabOther.Name = "tabOther";
            this.tabOther.Size = new System.Drawing.Size(792, 424);
            this.tabOther.TabIndex = 6;
            this.tabOther.Text = "Egyéb funkciók";
            // 
            // groupOtherFunctions
            // 
            this.groupOtherFunctions.Controls.Add(this.lblOtherOsszesBefizetesKivetel);
            this.groupOtherFunctions.Controls.Add(this.lblOtherKezdoDatum);
            this.groupOtherFunctions.Controls.Add(this.lblOtherVegDatum);
            this.groupOtherFunctions.Controls.Add(this.dtStatisticsDate);
            this.groupOtherFunctions.Controls.Add(this.dtStatisticsDateEnd);
            this.groupOtherFunctions.Controls.Add(this.btnStatistics);
            this.groupOtherFunctions.Controls.Add(this.btnExport);
            this.groupOtherFunctions.Controls.Add(this.btnBackup);
            this.groupOtherFunctions.Controls.Add(this.btnRestore);
            this.groupOtherFunctions.Controls.Add(this.listOtherResults);
            this.groupOtherFunctions.Location = new System.Drawing.Point(20, 20);
            this.groupOtherFunctions.Name = "groupOtherFunctions";
            this.groupOtherFunctions.Size = new System.Drawing.Size(740, 360);
            this.groupOtherFunctions.TabIndex = 0;
            this.groupOtherFunctions.TabStop = false;
            this.groupOtherFunctions.Text = "Funkciók";
            // 
            // lblOtherOsszesBefizetesKivetel
            // 
            this.lblOtherOsszesBefizetesKivetel.Location = new System.Drawing.Point(20, 20);
            this.lblOtherOsszesBefizetesKivetel.Name = "lblOtherOsszesBefizetesKivetel";
            this.lblOtherOsszesBefizetesKivetel.Size = new System.Drawing.Size(200, 15);
            this.lblOtherOsszesBefizetesKivetel.TabIndex = 0;
            this.lblOtherOsszesBefizetesKivetel.Text = "Összes befizetés/kivétel (időszak)";
            // 
            // lblOtherKezdoDatum
            // 
            this.lblOtherKezdoDatum.Location = new System.Drawing.Point(20, 40);
            this.lblOtherKezdoDatum.Name = "lblOtherKezdoDatum";
            this.lblOtherKezdoDatum.Size = new System.Drawing.Size(100, 15);
            this.lblOtherKezdoDatum.TabIndex = 1;
            this.lblOtherKezdoDatum.Text = "Kezdő dátum:";
            // 
            // lblOtherVegDatum
            // 
            this.lblOtherVegDatum.Location = new System.Drawing.Point(20, 66);
            this.lblOtherVegDatum.Name = "lblOtherVegDatum";
            this.lblOtherVegDatum.Size = new System.Drawing.Size(100, 15);
            this.lblOtherVegDatum.TabIndex = 2;
            this.lblOtherVegDatum.Text = "Vég dátum:";
            // 
            // dtStatisticsDate
            // 
            this.dtStatisticsDate.Location = new System.Drawing.Point(120, 40);
            this.dtStatisticsDate.Name = "dtStatisticsDate";
            this.dtStatisticsDate.Size = new System.Drawing.Size(150, 20);
            this.dtStatisticsDate.TabIndex = 3;
            // 
            // dtStatisticsDateEnd
            // 
            this.dtStatisticsDateEnd.Location = new System.Drawing.Point(120, 66);
            this.dtStatisticsDateEnd.Name = "dtStatisticsDateEnd";
            this.dtStatisticsDateEnd.Size = new System.Drawing.Size(150, 20);
            this.dtStatisticsDateEnd.TabIndex = 4;
            // 
            // btnStatistics
            // 
            this.btnStatistics.Location = new System.Drawing.Point(280, 40);
            this.btnStatistics.Name = "btnStatistics";
            this.btnStatistics.Size = new System.Drawing.Size(70, 46);
            this.btnStatistics.TabIndex = 5;
            this.btnStatistics.Text = "Keresés";
            this.btnStatistics.Click += new System.EventHandler(this.btnStatistics_Click);
            // 
            // btnExport
            // 
            this.btnExport.Location = new System.Drawing.Point(20, 284);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(227, 46);
            this.btnExport.TabIndex = 3;
            this.btnExport.Text = "Exportálás";
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // btnBackup
            // 
            this.btnBackup.Location = new System.Drawing.Point(20, 95);
            this.btnBackup.Name = "btnBackup";
            this.btnBackup.Size = new System.Drawing.Size(116, 23);
            this.btnBackup.TabIndex = 6;
            this.btnBackup.Text = "Mentés";
            this.btnBackup.Click += new System.EventHandler(this.btnBackup_Click);
            // 
            // btnRestore
            // 
            this.btnRestore.Location = new System.Drawing.Point(142, 95);
            this.btnRestore.Name = "btnRestore";
            this.btnRestore.Size = new System.Drawing.Size(108, 23);
            this.btnRestore.TabIndex = 7;
            this.btnRestore.Text = "Visszaállítás";
            this.btnRestore.Click += new System.EventHandler(this.btnRestore_Click);
            // 
            // listOtherResults
            // 
            this.listOtherResults.Location = new System.Drawing.Point(356, 40);
            this.listOtherResults.Name = "listOtherResults";
            this.listOtherResults.Size = new System.Drawing.Size(354, 290);
            this.listOtherResults.TabIndex = 6;
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Banki Szoftver";
            this.tabControl1.ResumeLayout(false);
            this.tabDisplay.ResumeLayout(false);
            this.groupDisplay.ResumeLayout(false);
            this.tabUjUgyfel.ResumeLayout(false);
            this.groupUjUgyfel.ResumeLayout(false);
            this.groupUjUgyfel.PerformLayout();
            this.tabSzamlaszam.ResumeLayout(false);
            this.groupSzamlaszam.ResumeLayout(false);
            this.groupSzamlaszam.PerformLayout();
            this.tabTranzakcio.ResumeLayout(false);
            this.groupTranzakcio.ResumeLayout(false);
            this.groupTranzakcio.PerformLayout();
            this.tabFilter.ResumeLayout(false);
            this.groupFilters.ResumeLayout(false);
            this.groupFilters.PerformLayout();
            this.tabSpecial.ResumeLayout(false);
            this.groupSpecialQueries.ResumeLayout(false);
            this.tabOther.ResumeLayout(false);
            this.groupOtherFunctions.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;

        private System.Windows.Forms.TabPage tabDisplay;

        private System.Windows.Forms.TabPage tabUjUgyfel;

        private System.Windows.Forms.TabPage tabSzamlaszam;

        private System.Windows.Forms.TabPage tabTranzakcio;

        private System.Windows.Forms.TabPage tabFilter;

        private System.Windows.Forms.TabPage tabSpecial;

        private System.Windows.Forms.TabPage tabOther;

        // banking controls...

        private System.Windows.Forms.GroupBox groupDisplay;

        private System.Windows.Forms.ListBox listCustomers;

        private System.Windows.Forms.ListBox listInvoices;

        private System.Windows.Forms.ListBox listTransactions;

        private System.Windows.Forms.GroupBox groupUjUgyfel;

        private System.Windows.Forms.Label lblNev;

        private System.Windows.Forms.Label lblLakcim;

        private System.Windows.Forms.Label lblSzuletesiDatum;

        private System.Windows.Forms.Label lblTelefonszam;

        private System.Windows.Forms.TextBox txtNev;

        private System.Windows.Forms.TextBox txtLakcim;

        private System.Windows.Forms.DateTimePicker dtSzuletesiDatum;

        private System.Windows.Forms.TextBox txtTelefonszam;

        private System.Windows.Forms.Button btnMentesUgyfel;

        private System.Windows.Forms.GroupBox groupSzamlaszam;

        private System.Windows.Forms.Label lblUgyfelValasztas;

        private System.Windows.Forms.ComboBox cmbUgyfel;

        private System.Windows.Forms.Label lblSzamlaszam;

        private System.Windows.Forms.Label lblSzamlatipus;

        private System.Windows.Forms.Label lblAktualisEgyenleg;

        private System.Windows.Forms.Label lblSzamlanyitasDatuma;

        private System.Windows.Forms.TextBox txtSzamlaszam;

        private System.Windows.Forms.ComboBox cmbSzamlatipus;

        private System.Windows.Forms.TextBox txtAktualisEgyenleg;

        private System.Windows.Forms.DateTimePicker dtSzamlanyitasDatuma;

        private System.Windows.Forms.Button btnMentesSzamla;

        private System.Windows.Forms.GroupBox groupTranzakcio;

        private System.Windows.Forms.Label lblSzamlaValasztas;

        private System.Windows.Forms.ComboBox cmbSzamla;

        private System.Windows.Forms.Label lblErintettSzamlaszam;

        private System.Windows.Forms.Label lblTipus;

        private System.Windows.Forms.Label lblOsszeg;

        private System.Windows.Forms.Label lblDatum;

        private System.Windows.Forms.TextBox txtErintettSzamlaszam;

        private System.Windows.Forms.TextBox txtTipus;

        private System.Windows.Forms.TextBox txtOsszeg;

        private System.Windows.Forms.DateTimePicker dtTranzakcioDatum;

        private System.Windows.Forms.Button btnMentesTranzakcio;

        private System.Windows.Forms.GroupBox groupFilters;

        private System.Windows.Forms.Label lblFilterUgyfelNeve;

        private System.Windows.Forms.TextBox txtFilterCustomer;

        private System.Windows.Forms.Button btnFilterCustomer;

        private System.Windows.Forms.Label lblFilterSzamlaKeresese;

        private System.Windows.Forms.TextBox txtFilterInvoice;

        private System.Windows.Forms.Button btnFilterInvoice;

        private System.Windows.Forms.Label lblFilterTranzakciokIdopont;

        private System.Windows.Forms.DateTimePicker dtFilterTransactionDate;

        private System.Windows.Forms.Button btnFilterTransactionDate;

        private System.Windows.Forms.ListBox listFilterResults;

        private System.Windows.Forms.GroupBox groupSpecialQueries;

        private System.Windows.Forms.Button btnNegativeBalance;

        private System.Windows.Forms.Button btnTopCustomer;

        private System.Windows.Forms.Label lblSpecialAdottIdoszak;

        private System.Windows.Forms.Label lblSpecialKezdoDatum;

        private System.Windows.Forms.Label lblSpecialVegDatum;

        private System.Windows.Forms.DateTimePicker dtDailyTransactionDate;

        private System.Windows.Forms.DateTimePicker dtDailyTransactionDateEnd;

        private System.Windows.Forms.Button btnDailyTransactionSummary;

        private System.Windows.Forms.ListBox listSpecialResults;

        private System.Windows.Forms.GroupBox groupOtherFunctions;

        private System.Windows.Forms.Label lblOtherOsszesBefizetesKivetel;

        private System.Windows.Forms.Label lblOtherKezdoDatum;

        private System.Windows.Forms.Label lblOtherVegDatum;

        private System.Windows.Forms.DateTimePicker dtStatisticsDate;

        private System.Windows.Forms.DateTimePicker dtStatisticsDateEnd;

        private System.Windows.Forms.Button btnStatistics;

        private System.Windows.Forms.Button btnExport;

        private System.Windows.Forms.Button btnBackup;

        private System.Windows.Forms.Button btnRestore;

        private System.Windows.Forms.ListBox listOtherResults;

    }

}

