﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BankiSzoftverOOP;

namespace BankiSzoftver
{
    public partial class Form1 : Form
    {
        private BankSystem _bankSystem;

        public Form1()
        {
            InitializeComponent();
            _bankSystem = new BankSystem();
            AdatokBetoltese();
        }

        private void AdatokBetoltese()
        {
            try
            {
                // Ügyfelek betöltése - strukturált formátum
                listCustomers.Items.Clear();
                foreach (var ugyfel in _bankSystem.Ugyfelek)
                {
                    listCustomers.Items.Add($"ÜgyfélID: {ugyfel.Id} | Név: {ugyfel.Nev} | Lakcím: {ugyfel.Lakcim} | Születés: {ugyfel.SzuletesiDatum:yyyy-MM-dd} | Telefon: {ugyfel.Telefonszam}");
                }

                // Számlák betöltése - strukturált formátum
                listInvoices.Items.Clear();
                foreach (var szamla in _bankSystem.Szamlak)
                {
                    listInvoices.Items.Add($"ÜgyfélID: {szamla.UgyfelId} | Számlaszám: {szamla.Szamlaszam} | Típus: {szamla.Szamlatipus} | Egyenleg: {szamla.AktualisEgyenleg:C} | Nyitás: {szamla.SzamlanyitasDatuma:yyyy-MM-dd}");
                }

                // Tranzakciók betöltése - strukturált formátum
                listTransactions.Items.Clear();
                foreach (var tranzakcio in _bankSystem.Tranzakciok)
                {
                    string partnerInfo = string.IsNullOrWhiteSpace(tranzakcio.PartnerSzamlaszam) ? "" : $" | Partner: {tranzakcio.PartnerSzamlaszam}";
                    listTransactions.Items.Add($"TranzakcióID: {tranzakcio.Id} | Számlaszám: {tranzakcio.ErintettSzamlaszam} | Típus: {tranzakcio.Tipus} | Összeg: {tranzakcio.Osszeg:C} | Dátum: {tranzakcio.Datum:yyyy-MM-dd}{partnerInfo}");
                }

                // Ügyfelek betöltése combobox-ba
                cmbUgyfel.Items.Clear();
                foreach (var ugyfel in _bankSystem.Ugyfelek)
                {
                    cmbUgyfel.Items.Add($"{ugyfel.Id} - {ugyfel.Nev}");
                }

                // Számlák betöltése combobox-ba
                cmbSzamla.Items.Clear();
                foreach (var szamla in _bankSystem.Szamlak)
                {
                    cmbSzamla.Items.Add(szamla.Szamlaszam);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba az adatok betöltésekor: {ex.Message}", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Új ügyfél mentése
        private void btnMentesUgyfel_Click(object sender, EventArgs e)
        {
            try
            {
                string nev = txtNev.Text;
                string lakcim = txtLakcim.Text;
                DateTime szuletesiDatum = dtSzuletesiDatum.Value;
                string telefonszam = txtTelefonszam.Text;

                _bankSystem.UjUgyfelRogzitese(nev, lakcim, szuletesiDatum, telefonszam);
                MessageBox.Show("Ügyfél sikeresen rögzítve!", "Siker", MessageBoxButtons.OK, MessageBoxIcon.Information);
                AdatokBetoltese();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba: {ex.Message}", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Új számla mentése
        private void btnMentesSzamla_Click(object sender, EventArgs e)
        {
            try
            {
                if (cmbUgyfel.SelectedItem == null)
                {
                    MessageBox.Show("Válasszon ügyfelet!", "Figyelmeztetés", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string ugyfelText = cmbUgyfel.SelectedItem.ToString();
                int ugyfelId = int.Parse(ugyfelText.Split('-')[0].Trim());
                string szamlaszam = txtSzamlaszam.Text?.Trim();
                
                if (string.IsNullOrWhiteSpace(szamlaszam))
                {
                    MessageBox.Show("Adja meg a számlaszámot!", "Figyelmeztetés", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Ellenőrzés, hogy létezik-e már a számlaszám
                if (_bankSystem.Szamlak.Any(s => s.Szamlaszam.Trim().Equals(szamlaszam, StringComparison.OrdinalIgnoreCase)))
                {
                    MessageBox.Show($"A számlaszám már létezik: {szamlaszam}\n\nKérjük, használjon másik számlaszámot!", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                string szamlatipus = cmbSzamlatipus.Text;
                if (string.IsNullOrWhiteSpace(szamlatipus))
                {
                    MessageBox.Show("Válasszon számlatípust!", "Figyelmeztetés", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                double kezdoEgyenleg = double.Parse(txtAktualisEgyenleg.Text);
                DateTime nyitasDatuma = dtSzamlanyitasDatuma.Value;

                _bankSystem.UjSzamlaNyitasa(szamlaszam, ugyfelId, szamlatipus, kezdoEgyenleg, nyitasDatuma);
                MessageBox.Show("Számla sikeresen nyitva!", "Siker", MessageBoxButtons.OK, MessageBoxIcon.Information);
                AdatokBetoltese();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba: {ex.Message}", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Tranzakció mentése
        private void btnMentesTranzakcio_Click(object sender, EventArgs e)
        {
            try
            {
                string szamlaszam = txtErintettSzamlaszam.Text;
                string tipus = txtTipus.Text;
                double osszeg = double.Parse(txtOsszeg.Text);
                DateTime datum = dtTranzakcioDatum.Value;
                string partnerSzamlaszam = "";

                if (tipus == "átutalás")
                {
                    if (cmbSzamla.SelectedItem == null)
                    {
                        MessageBox.Show("Átutalás esetén válasszon partner számlát!", "Figyelmeztetés", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    partnerSzamlaszam = cmbSzamla.SelectedItem.ToString();
                }

                _bankSystem.TranzakcioFelvitele(szamlaszam, tipus, osszeg, datum, partnerSzamlaszam);
                MessageBox.Show("Tranzakció sikeresen felvéve!", "Siker", MessageBoxButtons.OK, MessageBoxIcon.Information);
                AdatokBetoltese();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba: {ex.Message}", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Ügyfél keresése
        private void btnFilterCustomer_Click(object sender, EventArgs e)
        {
            try
            {
                string ugyfelNeve = txtFilterCustomer.Text;
                listFilterResults.Items.Clear();

                var talalatok = _bankSystem.Ugyfelek.Where(u => u.Nev.Contains(ugyfelNeve)).ToList();
                foreach (var ugyfel in talalatok)
                {
                    listFilterResults.Items.Add($"ID: {ugyfel.Id}, Név: {ugyfel.Nev}, Lakcím: {ugyfel.Lakcim}");
                    var szamlak = _bankSystem.Szamlak.Where(s => s.UgyfelId == ugyfel.Id).ToList();
                    foreach (var szamla in szamlak)
                    {
                        listFilterResults.Items.Add($"  - Számla: {szamla.Szamlaszam}, Egyenleg: {szamla.AktualisEgyenleg:C}");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba: {ex.Message}", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Számla keresése
        private void btnFilterInvoice_Click(object sender, EventArgs e)
        {
            try
            {
                string szamlaszam = txtFilterInvoice.Text?.Trim();
                if (string.IsNullOrWhiteSpace(szamlaszam))
                {
                    MessageBox.Show("Adja meg a számlaszámot!", "Figyelmeztetés", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                listFilterResults.Items.Clear();

                // Először ellenőrizzük, hogy létezik-e a számla
                var szamla = _bankSystem.Szamlak.FirstOrDefault(s => s.Szamlaszam.Trim().Equals(szamlaszam, StringComparison.OrdinalIgnoreCase));
                if (szamla == null)
                {
                    listFilterResults.Items.Add($"A számla nem található: {szamlaszam}");
                    listFilterResults.Items.Add("");
                    listFilterResults.Items.Add("Elérhető számlaszámok:");
                    foreach (var s in _bankSystem.Szamlak)
                    {
                        listFilterResults.Items.Add($"  - {s.Szamlaszam}");
                    }
                    return;
                }

                // Tranzakciók keresése
                var tranzakciok = _bankSystem.Tranzakciok
                    .Where(t => t.ErintettSzamlaszam != null && t.ErintettSzamlaszam.Trim().Equals(szamlaszam, StringComparison.OrdinalIgnoreCase))
                    .ToList();

                if (tranzakciok.Count == 0)
                {
                    listFilterResults.Items.Add($"Nincs tranzakció a számlához: {szamlaszam}");
                    listFilterResults.Items.Add($"Számla egyenlege: {szamla.AktualisEgyenleg:C}");
                }
                else
                {
                    listFilterResults.Items.Add($"Számla: {szamlaszam} - Egyenleg: {szamla.AktualisEgyenleg:C}");
                    listFilterResults.Items.Add($"Tranzakciók száma: {tranzakciok.Count}");
                    listFilterResults.Items.Add("");
                    foreach (var tranzakcio in tranzakciok)
                    {
                        string partnerInfo = string.IsNullOrWhiteSpace(tranzakcio.PartnerSzamlaszam) ? "" : $"Partner: {tranzakcio.PartnerSzamlaszam}";
                        listFilterResults.Items.Add($"{tranzakcio.Datum:yyyy-MM-dd HH:mm} - {tranzakcio.Tipus} - {tranzakcio.Osszeg:C} {partnerInfo}");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba: {ex.Message}", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Tranzakciók dátum szerint
        private void btnFilterTransactionDate_Click(object sender, EventArgs e)
        {
            try
            {
                DateTime datum = dtFilterTransactionDate.Value.Date;
                listFilterResults.Items.Clear();

                // Összes tranzakció dátumának ellenőrzése
                var tranzakciok = _bankSystem.Tranzakciok
                    .Where(t => t.Datum.Date == datum)
                    .OrderBy(t => t.Datum)
                    .ToList();

                if (tranzakciok.Count == 0)
                {
                    listFilterResults.Items.Add($"Nincs tranzakció a megadott dátumon: {datum:yyyy-MM-dd}");
                    listFilterResults.Items.Add("");
                    listFilterResults.Items.Add("Elérhető dátumok a tranzakciókban:");
                    var elerhetoDatumok = _bankSystem.Tranzakciok
                        .Select(t => t.Datum.Date)
                        .Distinct()
                        .OrderBy(d => d)
                        .Take(10)
                        .ToList();
                    foreach (var d in elerhetoDatumok)
                    {
                        listFilterResults.Items.Add($"  - {d:yyyy-MM-dd}");
                    }
                }
                else
                {
                    listFilterResults.Items.Add($"Tranzakciók {datum:yyyy-MM-dd} dátumon ({tranzakciok.Count} db):");
                    listFilterResults.Items.Add("");
                    double osszeg = 0;
                    foreach (var tranzakcio in tranzakciok)
                    {
                        string partnerInfo = string.IsNullOrWhiteSpace(tranzakcio.PartnerSzamlaszam) ? "" : $"Partner: {tranzakcio.PartnerSzamlaszam}";
                        listFilterResults.Items.Add($"{tranzakcio.Datum:HH:mm:ss} - {tranzakcio.Tipus} - {tranzakcio.Osszeg:C} - Számla: {tranzakcio.ErintettSzamlaszam} {partnerInfo}");
                        if (tranzakcio.Tipus == "befizetés" || (tranzakcio.Tipus == "átutalás" && !string.IsNullOrWhiteSpace(tranzakcio.PartnerSzamlaszam)))
                        {
                            osszeg += tranzakcio.Osszeg;
                        }
                        else
                        {
                            osszeg -= tranzakcio.Osszeg;
                        }
                    }
                    listFilterResults.Items.Add("");
                    listFilterResults.Items.Add($"Napi összes forgalom: {osszeg:C}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba: {ex.Message}", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Negatív egyenlegű számlák
        private void btnNegativeBalance_Click(object sender, EventArgs e)
        {
            try
            {
                listSpecialResults.Items.Clear();
                _bankSystem.NegativEgyenleguSzamlakListazasa();
                var negativSzamlak = _bankSystem.Szamlak.Where(s => s.AktualisEgyenleg < 0).ToList();
                foreach (var szamla in negativSzamlak)
                {
                    listSpecialResults.Items.Add($"Számlaszám: {szamla.Szamlaszam}, Egyenleg: {szamla.AktualisEgyenleg:C}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba: {ex.Message}", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Adott időszak tranzakciói (két dátum között)
        private void btnDailyTransactionSummary_Click(object sender, EventArgs e)
        {
            try
            {
                DateTime kezdoDatum = dtDailyTransactionDate.Value.Date;
                DateTime vegDatum = dtDailyTransactionDateEnd.Value.Date.AddDays(1).AddTicks(-1); // Vég dátum végéig

                if (vegDatum < kezdoDatum)
                {
                    MessageBox.Show("A vég dátum nem lehet korábbi, mint a kezdő dátum!", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                listSpecialResults.Items.Clear();

                var tranzakciok = _bankSystem.Tranzakciok
                    .Where(t => t.Datum >= kezdoDatum && t.Datum <= vegDatum)
                    .OrderBy(t => t.Datum)
                    .ToList();

                if (tranzakciok.Count == 0)
                {
                    listSpecialResults.Items.Add($"Nincs tranzakció a megadott időszakban ({kezdoDatum:yyyy-MM-dd} - {vegDatum.Date:yyyy-MM-dd}).");
                }
                else
                {
                    listSpecialResults.Items.Add($"=== TRANZAKCIÓK {kezdoDatum:yyyy-MM-dd} - {vegDatum.Date:yyyy-MM-dd} ===");
                    listSpecialResults.Items.Add($"Összesen: {tranzakciok.Count} db tranzakció");
                    listSpecialResults.Items.Add("");
                    
                double osszesBefizetes = 0;
                double osszesKivetel = 0;

                    foreach (var tranzakcio in tranzakciok)
                    {
                        string partnerInfo = string.IsNullOrWhiteSpace(tranzakcio.PartnerSzamlaszam) ? "" : $" | Partner: {tranzakcio.PartnerSzamlaszam}";
                        listSpecialResults.Items.Add($"{tranzakcio.Datum:yyyy-MM-dd HH:mm} | {tranzakcio.Tipus} | {tranzakcio.Osszeg:C} | Számla: {tranzakcio.ErintettSzamlaszam}{partnerInfo}");
                        
                        if (tranzakcio.Tipus == "befizetés" || (tranzakcio.Tipus == "átutalás" && !string.IsNullOrWhiteSpace(tranzakcio.PartnerSzamlaszam)))
                        {
                            osszesBefizetes += tranzakcio.Osszeg;
                        }
                        else
                        {
                            osszesKivetel += tranzakcio.Osszeg;
                        }
                    }

                    listSpecialResults.Items.Add("");
                    listSpecialResults.Items.Add($"Összes befizetés: {osszesBefizetes:C}");
                    listSpecialResults.Items.Add($"Összes kivétel: {osszesKivetel:C}");
                    listSpecialResults.Items.Add($"Nettó forgalom: {osszesBefizetes - osszesKivetel:C}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba: {ex.Message}", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Tranzakciók szűrése (napi/heti/havi)
        private void TranzakciokSzurese(string tipus)
        {
            try
            {
                _bankSystem.TranzakciokSzurese(tipus);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba: {ex.Message}", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Legnagyobb forgalmú ügyfél
        private void btnTopCustomer_Click(object sender, EventArgs e)
        {
            try
            {
                listSpecialResults.Items.Clear();

                // Minden ügyfélhez számoljuk a forgalmat (összes tranzakció összege)
                var ugyfelForgalom = _bankSystem.Ugyfelek
                    .Select(ugyfel => new
                    {
                        Ugyfel = ugyfel,
                        Szamlak = _bankSystem.Szamlak.Where(s => s.UgyfelId == ugyfel.Id).ToList(),
                        Forgalom = _bankSystem.Tranzakciok
                            .Where(t => _bankSystem.Szamlak.Any(s => s.Szamlaszam == t.ErintettSzamlaszam && s.UgyfelId == ugyfel.Id))
                            .Sum(t => Math.Abs(t.Osszeg))
                    })
                    .OrderByDescending(x => x.Forgalom)
                    .ToList();

                if (ugyfelForgalom.Count == 0 || ugyfelForgalom.All(x => x.Forgalom == 0))
                {
                    listSpecialResults.Items.Add("Nincs forgalom az ügyfelek között.");
                    return;
                }

                var topUgyfel = ugyfelForgalom.First();
                listSpecialResults.Items.Add("=== LEGNAGYOBB FORGALMÚ ÜGYFÉL ===");
                listSpecialResults.Items.Add("");
                listSpecialResults.Items.Add($"Ügyfél ID: {topUgyfel.Ugyfel.Id}");
                listSpecialResults.Items.Add($"Név: {topUgyfel.Ugyfel.Nev}");
                listSpecialResults.Items.Add($"Lakcím: {topUgyfel.Ugyfel.Lakcim}");
                listSpecialResults.Items.Add($"Telefon: {topUgyfel.Ugyfel.Telefonszam}");
                listSpecialResults.Items.Add($"Összes forgalom: {topUgyfel.Forgalom:C}");
                listSpecialResults.Items.Add($"Számlák száma: {topUgyfel.Szamlak.Count}");
                listSpecialResults.Items.Add("");
                listSpecialResults.Items.Add("Számlái:");
                foreach (var szamla in topUgyfel.Szamlak)
                {
                    listSpecialResults.Items.Add($"  - {szamla.Szamlaszam} ({szamla.Szamlatipus}): {szamla.AktualisEgyenleg:C}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba: {ex.Message}", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Statisztikák (összes befizetés/kivétel adott időszakban)
        private void btnStatistics_Click(object sender, EventArgs e)
        {
            try
            {
                DateTime kezdoDatum = dtStatisticsDate.Value.Date;
                DateTime vegDatum = dtStatisticsDateEnd.Value.Date.AddDays(1).AddTicks(-1); // Vég dátum végéig

                if (vegDatum < kezdoDatum)
                {
                    MessageBox.Show("A vég dátum nem lehet korábbi, mint a kezdő dátum!", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                listOtherResults.Items.Clear();

                var tranzakciok = _bankSystem.Tranzakciok
                    .Where(t => t.Datum >= kezdoDatum && t.Datum <= vegDatum)
                    .ToList();
                
                double osszesBefizetes = tranzakciok
                    .Where(t => t.Tipus == "befizetés" || (t.Tipus == "átutalás" && !string.IsNullOrWhiteSpace(t.PartnerSzamlaszam)))
                    .Sum(t => t.Osszeg);

                double osszesKivetel = tranzakciok
                    .Where(t => t.Tipus == "készpénzfelvétel" || (t.Tipus == "átutalás" && string.IsNullOrWhiteSpace(t.PartnerSzamlaszam)))
                    .Sum(t => t.Osszeg);

                listOtherResults.Items.Add($"=== STATISZTIKÁK {kezdoDatum:yyyy-MM-dd} - {vegDatum.Date:yyyy-MM-dd} ===");
                listOtherResults.Items.Add("");
                listOtherResults.Items.Add($"Időszak: {kezdoDatum:yyyy-MM-dd} - {vegDatum.Date:yyyy-MM-dd}");
                listOtherResults.Items.Add($"Tranzakciók száma: {tranzakciok.Count}");
                listOtherResults.Items.Add("");
                listOtherResults.Items.Add($"Összes befizetés: {osszesBefizetes:C}");
                listOtherResults.Items.Add($"Összes kivétel: {osszesKivetel:C}");
                listOtherResults.Items.Add($"Nettó forgalom: {osszesBefizetes - osszesKivetel:C}");
                
                if (tranzakciok.Count > 0)
                {
                    listOtherResults.Items.Add("");
                    listOtherResults.Items.Add("Típus szerinti bontás:");
                    var tipusBontas = tranzakciok.GroupBy(t => t.Tipus)
                        .Select(g => new { Tipus = g.Key, Osszeg = g.Sum(t => t.Osszeg), Darab = g.Count() })
                        .OrderByDescending(x => x.Osszeg);
                    
                    foreach (var item in tipusBontas)
                    {
                        listOtherResults.Items.Add($"  {item.Tipus}: {item.Osszeg:C} ({item.Darab} db)");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba: {ex.Message}", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Exportálás
        private void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                SaveFileDialog saveDialog = new SaveFileDialog();
                saveDialog.Filter = "Szöveges fájl (*.txt)|*.txt|Minden fájl (*.*)|*.*";
                saveDialog.FileName = $"banki_adatok_export_{DateTime.Now:yyyyMMdd_HHmmss}.txt";

                if (saveDialog.ShowDialog() == DialogResult.OK)
                {
                    using (System.IO.StreamWriter writer = new System.IO.StreamWriter(saveDialog.FileName))
                    {
                        writer.WriteLine("=== BANKI ADATOK EXPORT ===");
                        writer.WriteLine($"Export dátum: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
                        writer.WriteLine("");

                        writer.WriteLine("=== ÜGYFELEK ===");
                        foreach (var ugyfel in _bankSystem.Ugyfelek)
                        {
                            writer.WriteLine($"ID: {ugyfel.Id} | Név: {ugyfel.Nev} | Lakcím: {ugyfel.Lakcim} | Születés: {ugyfel.SzuletesiDatum:yyyy-MM-dd} | Telefon: {ugyfel.Telefonszam}");
                        }
                        writer.WriteLine("");

                        writer.WriteLine("=== SZÁMLÁK ===");
                        foreach (var szamla in _bankSystem.Szamlak)
                        {
                            writer.WriteLine($"ÜgyfélID: {szamla.UgyfelId} | Számlaszám: {szamla.Szamlaszam} | Típus: {szamla.Szamlatipus} | Egyenleg: {szamla.AktualisEgyenleg} | Nyitás: {szamla.SzamlanyitasDatuma:yyyy-MM-dd}");
                        }
                        writer.WriteLine("");

                        writer.WriteLine("=== TRANZAKCIÓK ===");
                        foreach (var tranzakcio in _bankSystem.Tranzakciok)
                        {
                            writer.WriteLine($"ID: {tranzakcio.Id} | Számla: {tranzakcio.ErintettSzamlaszam} | Típus: {tranzakcio.Tipus} | Összeg: {tranzakcio.Osszeg} | Dátum: {tranzakcio.Datum:yyyy-MM-dd} | Partner: {tranzakcio.PartnerSzamlaszam}");
                        }
                    }

                    MessageBox.Show($"Adatok sikeresen exportálva: {saveDialog.FileName}", "Siker", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba az exportálás során: {ex.Message}", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Mentés (Backup)
        private void btnBackup_Click(object sender, EventArgs e)
        {
            try
            {
                _bankSystem.AdatokMentese();
                MessageBox.Show("Adatok sikeresen mentve!", "Siker", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba a mentés során: {ex.Message}", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Visszaállítás (Restore - újratöltés)
        private void btnRestore_Click(object sender, EventArgs e)
        {
            try
            {
                var result = MessageBox.Show("Biztosan vissza szeretné állítani az adatokat? Ez felülírja a jelenlegi memóriában lévő adatokat.", "Visszaállítás", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    _bankSystem.AdatokBetoltese();
                    AdatokBetoltese();
                    MessageBox.Show("Adatok sikeresen visszaállítva!", "Siker", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba a visszaállítás során: {ex.Message}", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
