using System;
using NUnit.Framework;
using NUnit.Framework.Legacy;
using BankiSzoftverOOP;

namespace Teszteles
{
    [TestFixture]
    public class TransactionTests
    {
        [Test]
        public void IsValid_NegativOsszeg_False()
        {
            Transaction tranzakcio = new Transaction(1, "TEST013", "befizetés", -500, DateTime.Now);
            ClassicAssert.IsFalse(tranzakcio.IsValid());
        }

        [Test]
        public void IsValid_HianyzoCelSzamla_False()
        {
            Transaction tranzakcio = new Transaction(1, "", "befizetés", 500, DateTime.Now);
            ClassicAssert.IsFalse(tranzakcio.IsValid());
        }

        [Test]
        [TestCase(10000, 100, 100)]
        public void CalculateFee_1SzazalekDij_SzamoljaHelyesen(double osszeg, double minFee, double elvart)
        {
            Transaction tranzakcio = new Transaction(1, "TEST015", "befizetés", osszeg, DateTime.Now);
            ClassicAssert.AreEqual(elvart, tranzakcio.CalculateFee(minFee), 0.01);
        }

        [Test]
        [TestCase(100, 100, 100)]
        public void CalculateFee_MinimumDij_Ervenyesul(double osszeg, double minFee, double elvart)
        {
            Transaction tranzakcio = new Transaction(1, "TEST016", "befizetés", osszeg, DateTime.Now);
            ClassicAssert.AreEqual(elvart, tranzakcio.CalculateFee(minFee), 0.01);
        }
    }
}

