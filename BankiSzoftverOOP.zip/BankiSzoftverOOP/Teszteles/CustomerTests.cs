using System;
using System.Collections.Generic;
using NUnit.Framework;
using NUnit.Framework.Legacy;
using BankiSzoftverOOP;

namespace Teszteles
{
    [TestFixture]
    public class CustomerTests
    {
        [Test]
        public void AddAccount_UjSzamlaHozzaadasa_NoveliSzamlakSzamat()
        {
            Customer ugyfel = new Customer(1, "Test", "Test", DateTime.Now, "123");
            List<Account> szamlak = new List<Account>();
            Account ujSzamla = new Account("TEST010", 1, "folyószámla", 1000, DateTime.Now);
            ugyfel.AddAccount(ujSzamla, szamlak);
            ClassicAssert.AreEqual(1, szamlak.Count);
        }

        [Test]
        public void AddAccount_DuplikaltSzamlaszam_DobKivetelt()
        {
            Customer ugyfel = new Customer(1, "Test", "Test", DateTime.Now, "123");
            List<Account> szamlak = new List<Account>();
            Account szamla1 = new Account("TEST011", 1, "folyószámla", 1000, DateTime.Now);
            Account szamla2 = new Account("TEST011", 1, "folyószámla", 2000, DateTime.Now);
            ugyfel.AddAccount(szamla1, szamlak);
            ClassicAssert.Throws<InvalidOperationException>(() => ugyfel.AddAccount(szamla2, szamlak));
        }

        [Test]
        [TestCase(1000, 3000, 4000)]
        public void GetTotalBalance_TobbSzamlaEgyenlege_OsszegziAzEgyenlegeket(double egyenleg1, double egyenleg2, double elvart)
        {
            Customer ugyfel = new Customer(1, "Test", "Test", DateTime.Now, "123");
            List<Account> szamlak = new List<Account>
            {
                new Account("TEST012A", 1, "folyószámla", egyenleg1, DateTime.Now),
                new Account("TEST012B", 1, "folyószámla", egyenleg2, DateTime.Now)
            };
            ClassicAssert.AreEqual(elvart, ugyfel.GetTotalBalance(szamlak), 0.01);
        }
    }
}

