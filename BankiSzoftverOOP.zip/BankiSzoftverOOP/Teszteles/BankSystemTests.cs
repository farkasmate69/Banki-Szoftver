using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using NUnit.Framework.Legacy;
using BankiSzoftverOOP;

namespace Teszteles
{
    [TestFixture]
    public class BankSystemTests
    {
        [Test]
        public void FindCustomerById_LetezoUgyfel_VisszaadjaAzUgyfelt()
        {
            BankSystem bankSystem = new BankSystem();
            Customer ujUgyfel = new Customer(123, "Test", "Test", DateTime.Now, "123");
            bankSystem.Ugyfelek.Add(ujUgyfel);
            Customer talalt = bankSystem.FindCustomerById(123);
            ClassicAssert.IsNotNull(talalt);
            ClassicAssert.AreEqual(123, talalt.Id);
        }

        [Test]
        public void FindCustomerById_NemLetezoUgyfel_Null()
        {
            BankSystem bankSystem = new BankSystem();
            Customer talalt = bankSystem.FindCustomerById(999);
            ClassicAssert.IsNull(talalt);
        }

        [Test]
        public void GetOverdrawnAccounts_NegativEgyenleguSzamlak_VisszaadjaAListat()
        {
            BankSystem bankSystem = new BankSystem();
            Account szamla1 = new Account("TEST019A", 1, "folyószámla", 1000, DateTime.Now);
            Account szamla2 = new Account("TEST019B", 1, "folyószámla", -200, DateTime.Now);
            Account szamla3 = new Account("TEST019C", 1, "folyószámla", 300, DateTime.Now);
            Account szamla4 = new Account("TEST019D", 1, "folyószámla", -50, DateTime.Now);
            bankSystem.Szamlak.Add(szamla1);
            bankSystem.Szamlak.Add(szamla2);
            bankSystem.Szamlak.Add(szamla3);
            bankSystem.Szamlak.Add(szamla4);
            var negativSzamlak = bankSystem.GetOverdrawnAccounts();
            ClassicAssert.AreEqual(2, negativSzamlak.Count);
            ClassicAssert.IsTrue(negativSzamlak.Any(s => s.Szamlaszam == "TEST019B"));
            ClassicAssert.IsTrue(negativSzamlak.Any(s => s.Szamlaszam == "TEST019D"));
        }

        [Test]
        public void FindAccountByNumber_RosszFormatum_DobKivetelt()
        {
            BankSystem bankSystem = new BankSystem();
            ClassicAssert.Throws<ArgumentException>(() => bankSystem.FindAccountByNumber(""));
        }
    }
}

