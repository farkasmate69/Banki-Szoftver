using System;
using System.Collections.Generic;
using NUnit.Framework;
using NUnit.Framework.Legacy;
using BankiSzoftverOOP;

namespace Teszteles
{
    [TestFixture]
    public class AccountTests
    {
        [Test]
        [TestCase(1000, 500, 1500)]
        public void Deposit_PozitivOsszeg_NoveliAzEgyenleget(double kezdoEgyenleg, double befizetes, double elvart)
        {
            Account szamla = new Account("TEST001", 1, "folyószámla", kezdoEgyenleg, DateTime.Now);
            szamla.Deposit(befizetes);
            ClassicAssert.AreEqual(elvart, szamla.GetBalance(), 0.01);
        }

        [Test]
        public void Deposit_NegativOsszeg_DobKivetelt()
        {
            Account szamla = new Account("TEST002", 1, "folyószámla", 1000, DateTime.Now);
            ClassicAssert.Throws<ArgumentException>(() => szamla.Deposit(-200));
        }

        [Test]
        [TestCase(2000, 500, 1500)]
        public void Withdraw_ElegendEgyenleg_CsokkentiAzEgyenleget(double kezdoEgyenleg, double kivet, double elvart)
        {
            Account szamla = new Account("TEST003", 1, "folyószámla", kezdoEgyenleg, DateTime.Now);
            szamla.Withdraw(kivet);
            ClassicAssert.AreEqual(elvart, szamla.GetBalance(), 0.01);
        }

        [Test]
        public void Withdraw_ElegtelenEgyenleg_DobKivetelt()
        {
            Account szamla = new Account("TEST004", 1, "folyószámla", 300, DateTime.Now);
            ClassicAssert.Throws<InvalidOperationException>(() => szamla.Withdraw(1000));
        }

        [Test]
        [TestCase(5000, 4999, true)]
        public void HasSufficientFunds_VanElegPenz_True(double egyenleg, double osszeg, bool elvart)
        {
            Account szamla = new Account("TEST005", 1, "folyószámla", egyenleg, DateTime.Now);
            ClassicAssert.AreEqual(elvart, szamla.HasSufficientFunds(osszeg));
        }

        [Test]
        [TestCase(200, 201, false)]
        public void HasSufficientFunds_NincsElegPenz_False(double egyenleg, double osszeg, bool elvart)
        {
            Account szamla = new Account("TEST006", 1, "folyószámla", egyenleg, DateTime.Now);
            ClassicAssert.AreEqual(elvart, szamla.HasSufficientFunds(osszeg));
        }

        [Test]
        [TestCase(5000, 1000, 2000, 3000, 3000)]
        public void TransferTo_SikeresAtutalas_LevonjaEsHozzaadja(double egyenlegA, double egyenlegB, double osszeg, double elvartA, double elvartB)
        {
            Account szamlaA = new Account("TEST007A", 1, "folyószámla", egyenlegA, DateTime.Now);
            Account szamlaB = new Account("TEST007B", 2, "folyószámla", egyenlegB, DateTime.Now);
            szamlaA.TransferTo(szamlaB, osszeg);
            ClassicAssert.AreEqual(elvartA, szamlaA.GetBalance(), 0.01);
            ClassicAssert.AreEqual(elvartB, szamlaB.GetBalance(), 0.01);
        }

        [Test]
        public void TransferTo_ElegtelenEgyenleg_DobKiveteltEsAllapotNemValtozik()
        {
            Account szamlaA = new Account("TEST008A", 1, "folyószámla", 1000, DateTime.Now);
            Account szamlaB = new Account("TEST008B", 2, "folyószámla", 1000, DateTime.Now);
            double eredetiA = szamlaA.GetBalance();
            double eredetiB = szamlaB.GetBalance();
            ClassicAssert.Throws<InvalidOperationException>(() => szamlaA.TransferTo(szamlaB, 5000));
            ClassicAssert.AreEqual(eredetiA, szamlaA.GetBalance(), 0.01);
            ClassicAssert.AreEqual(eredetiB, szamlaB.GetBalance(), 0.01);
        }

        [Test]
        [TestCase(900, 900)]
        public void GetBalance_PozitivKezdoErtek_VisszaadjaAzEgyenleget(double egyenleg, double elvart)
        {
            Account szamla = new Account("TEST009", 1, "folyószámla", egyenleg, DateTime.Now);
            ClassicAssert.AreEqual(elvart, szamla.GetBalance(), 0.01);
        }
    }
}

