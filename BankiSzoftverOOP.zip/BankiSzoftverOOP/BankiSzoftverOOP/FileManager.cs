using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace BankiSzoftverOOP
{
    public class FileManager
    {
        private const string CustomersFile = "ugyfelek.txt";
        private const string AccountsFile = "szamlak.txt";
        private const string TransactionsFile = "tranzakciok.txt";

        public List<Customer> UgyfelekBetoltese()
        {
            List<Customer> ugyfelek = new List<Customer>();
            try
            {
                if (File.Exists(CustomersFile))
                {
                    ugyfelek = File.ReadAllLines(CustomersFile)
                        .Where(line => !string.IsNullOrWhiteSpace(line))
                        .Select(Customer.FromString).ToList();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Hiba az ügyfelek betöltésekor: {ex.Message}");
            }
            finally
            {
            }
            return ugyfelek;
        }

        public List<Account> SzamlakBetoltese()
        {
            List<Account> szamlak = new List<Account>();
            try
            {
                if (File.Exists(AccountsFile))
                {
                    szamlak = File.ReadAllLines(AccountsFile)
                        .Where(line => !string.IsNullOrWhiteSpace(line))
                        .Select(Account.FromString).ToList();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Hiba a számlák betöltésekor: {ex.Message}");
            }
            finally
            {
            }
            return szamlak;
        }

        public List<Transaction> TranzakciokBetoltese()
        {
            List<Transaction> tranzakciok = new List<Transaction>();
            try
            {
                if (File.Exists(TransactionsFile))
                {
                    tranzakciok = File.ReadAllLines(TransactionsFile)
                        .Where(line => !string.IsNullOrWhiteSpace(line))
                        .Select(Transaction.FromString).ToList();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Hiba a tranzakciók betöltésekor: {ex.Message}");
            }
            finally
            {
            }
            return tranzakciok;
        }

        public void UgyfelekMentese(List<Customer> ugyfelek)
        {
            try
            {
                File.WriteAllLines(CustomersFile, ugyfelek.Select(u => u.ToString()));
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Hiba az ügyfelek mentésekor: {ex.Message}");
            }
            finally
            {
            }
        }

        public void SzamlakMentese(List<Account> szamlak)
        {
            try
            {
                File.WriteAllLines(AccountsFile, szamlak.Select(s => s.ToString()));
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Hiba a számlák mentésekor: {ex.Message}");
            }
            finally
            {
            }
        }

        public void TranzakciokMentese(List<Transaction> tranzakciok)
        {
            try
            {
                File.WriteAllLines(TransactionsFile, tranzakciok.Select(t => t.ToString()));
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Hiba a tranzakciók mentésekor: {ex.Message}");
            }
            finally
            {
            }
        }

        public void UjUgyfelHozzaadasaFajlhoz(Customer ugyfel)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(CustomersFile, append: true))
                {
                    writer.WriteLine(ugyfel.ToString());
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Hiba az új ügyfél hozzáadásakor: {ex.Message}");
            }
            finally
            {
            }
        }

        public void UjSzamlaHozzaadasaFajlhoz(Account szamla)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(AccountsFile, append: true))
                {
                    writer.WriteLine(szamla.ToString());
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Hiba az új számla hozzáadásakor: {ex.Message}");
            }
            finally
            {
            }
        }

        public void UjTranzakcioHozzaadasaFajlhoz(Transaction tranzakcio)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(TransactionsFile, append: true))
                {
                    writer.WriteLine(tranzakcio.ToString());
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Hiba az új tranzakció hozzáadásakor: {ex.Message}");
            }
            finally
            {
            }
        }
    }
}
