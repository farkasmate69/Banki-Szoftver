﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace BankiSzoftverOOP
{
    public class Customer
    {
        public int Id { get; set; }
        public string Nev { get; set; }
        public string Lakcim { get; set; }
        public DateTime SzuletesiDatum { get; set; }
        public string Telefonszam { get; set; }

        public Customer()
        {
        }

        public Customer(int id, string nev, string lakcim, DateTime szuletesiDatum, string telefonszam)
        {
            Id = id;
            Nev = nev;
            Lakcim = lakcim;
            SzuletesiDatum = szuletesiDatum;
            Telefonszam = telefonszam;
        }

        public override string ToString()
        {
            return $"{Id};{Nev};{Lakcim};{SzuletesiDatum:yyyy-MM-dd};{Telefonszam}";
        }

        public static Customer FromString(string line)
        {
            var parts = line.Split(';');
            return new Customer
            {
                Id = int.Parse(parts[0]),
                Nev = parts[1],
                Lakcim = parts[2],
                SzuletesiDatum = DateTime.Parse(parts[3]),
                Telefonszam = parts[4]
            };
        }

        public void AddAccount(Account account, List<Account> szamlak)
        {
            try
            {
                if (account == null) throw new ArgumentNullException();
                if (account.UgyfelId != Id) throw new InvalidOperationException();
                if (szamlak.Any(s => s.Szamlaszam == account.Szamlaszam)) throw new InvalidOperationException();
                szamlak.Add(account);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
            }
        }

        public double GetTotalBalance(List<Account> szamlak)
        {
            try
            {
                double osszeg = 0;
                foreach (var szamla in szamlak)
                {
                    if (szamla.UgyfelId == Id)
                    {
                        osszeg += Convert.ToDouble(szamla.AktualisEgyenleg);
                    }
                }
                return osszeg;
            }
            catch (Exception)
            {
                return 0;
            }
            finally
            {
            }
        }
    }
}
