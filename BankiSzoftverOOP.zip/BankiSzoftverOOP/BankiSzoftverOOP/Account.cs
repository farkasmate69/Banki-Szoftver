using System;

namespace BankiSzoftverOOP
{
    public class Account
    {
        public string Szamlaszam { get; set; }
        public int UgyfelId { get; set; }
        public string Szamlatipus { get; set; }
        public double AktualisEgyenleg { get; set; }
        public DateTime SzamlanyitasDatuma { get; set; }

        public Account()
        {
        }

        public Account(string szamlaszam, int ugyfelId, string szamlatipus, double aktualisEgyenleg, DateTime szamlanyitasDatuma)
        {
            Szamlaszam = szamlaszam;
            UgyfelId = ugyfelId;
            Szamlatipus = szamlatipus;
            AktualisEgyenleg = aktualisEgyenleg;
            SzamlanyitasDatuma = szamlanyitasDatuma;
        }

        public override string ToString()
        {
            return $"{Szamlaszam};{UgyfelId};{Szamlatipus};{AktualisEgyenleg};{SzamlanyitasDatuma:yyyy-MM-dd}";
        }

        public static Account FromString(string line)
        {
            var parts = line.Split(';');
            return new Account
            {
                Szamlaszam = parts[0],
                UgyfelId = int.Parse(parts[1]),
                Szamlatipus = parts[2],
                AktualisEgyenleg = double.Parse(parts[3]),
                SzamlanyitasDatuma = DateTime.Parse(parts[4])
            };
        }

        public void Deposit(double amount)
        {
            try
            {
                if (amount < 0) throw new ArgumentException();
                AktualisEgyenleg += amount;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
            }
        }

        public void Withdraw(double amount)
        {
            try
            {
                if (amount < 0) throw new ArgumentException();
                if (!HasSufficientFunds(amount)) throw new InvalidOperationException();
                AktualisEgyenleg -= amount;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
            }
        }

        public void TransferTo(Account targetAccount, double amount)
        {
            try
            {
                if (targetAccount == null) throw new ArgumentNullException();
                if (amount < 0) throw new ArgumentException();
                if (!HasSufficientFunds(amount)) throw new InvalidOperationException();
                AktualisEgyenleg -= amount;
                targetAccount.AktualisEgyenleg += amount;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
            }
        }

        public bool HasSufficientFunds(double amount)
        {
            try
            {
                return AktualisEgyenleg >= amount;
            }
            catch (Exception)
            {
                return false;
            }
            finally
            {
            }
        }

        public double GetBalance()
        {
            try
            {
                return AktualisEgyenleg;
            }
            catch (Exception)
            {
                return 0;
            }
            finally
            {
            }
        }
    }
}

