using System;
using System.Collections.Generic;
using System.Linq;

namespace BankiSzoftverOOP
{
    public class BankSystem
    {
        private List<Customer> _ugyfelek;
        private List<Account> _szamlak;
        private List<Transaction> _tranzakciok;
        private FileManager _fileManager;
        private CustomerService _customerService;
        private AccountService _accountService;
        private TransactionService _transactionService;

        public List<Customer> Ugyfelek => _ugyfelek;
        public List<Account> Szamlak => _szamlak;
        public List<Transaction> Tranzakciok => _tranzakciok;

        public BankSystem()
        {
            _fileManager = new FileManager();
            AdatokBetoltese();
            _customerService = new CustomerService(_ugyfelek);
            _accountService = new AccountService(_szamlak, _ugyfelek);
            _transactionService = new TransactionService(_tranzakciok, _szamlak);
        }

        public void AdatokBetoltese()
        {
            try
            {
                _ugyfelek = _fileManager.UgyfelekBetoltese();
                _szamlak = _fileManager.SzamlakBetoltese();
                _tranzakciok = _fileManager.TranzakciokBetoltese();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Hiba az adatok betöltésekor: {ex.Message}");
            }
            finally
            {
            }
        }

        public void AdatokMentese()
        {
            try
            {
                _fileManager.UgyfelekMentese(_ugyfelek);
                _fileManager.SzamlakMentese(_szamlak);
                _fileManager.TranzakciokMentese(_tranzakciok);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Hiba az adatok mentésekor: {ex.Message}");
            }
            finally
            {
            }
        }

        public void UjUgyfelRogzitese(string nev, string lakcim, DateTime szuletesiDatum, string telefonszam)
        {
            try
            {
                var ujUgyfel = _customerService.UgyfelLetrehozasa(nev, lakcim, szuletesiDatum, telefonszam);
                _customerService.UgyfelHozzaadasa(ujUgyfel);
                _fileManager.UjUgyfelHozzaadasaFajlhoz(ujUgyfel);
                Console.WriteLine($"Ügyfél sikeresen rögzítve! (ID: {ujUgyfel.Id})\n");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Hiba: {ex.Message}");
            }
            finally
            {
            }
        }

        public void UjSzamlaNyitasa(string szamlaszam, int ugyfelId, string szamlatipus, double kezdoEgyenleg, DateTime nyitasDatuma)
        {
            try
            {
                if (!_accountService.UgyfelLetezik(ugyfelId))
                {
                    Console.WriteLine("Az ügyfél nem található!");
                    return;
                }
                if (_accountService.SzamlaLetezik(szamlaszam))
                {
                    Console.WriteLine("A számlaszám már létezik!");
                    return;
                }

                var ujSzamla = _accountService.SzamlaLetrehozasa(szamlaszam, ugyfelId, szamlatipus, kezdoEgyenleg, nyitasDatuma);
                _accountService.SzamlaHozzaadasa(ujSzamla);
                _fileManager.UjSzamlaHozzaadasaFajlhoz(ujSzamla);
                Console.WriteLine("Számla sikeresen nyitva!");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Hiba: {ex.Message}");
            }
            finally
            {
            }
        }

        public void TranzakcioFelvitele(string szamlaszam, string tipus, double osszeg, DateTime datum, string partnerSzamlaszam = "")
        {
            try
            {
                var szamla = _accountService.SzamlaKeresese(szamlaszam);
                if (szamla == null)
                {
                    Console.WriteLine("A számla nem található!");
                    return;
                }

                if (tipus == "átutalás" && string.IsNullOrEmpty(partnerSzamlaszam))
                {
                    Console.WriteLine("Átutalás esetén meg kell adni a partner számlaszámát!");
                    return;
                }

                _transactionService.EgyenlegFrissitese(szamlaszam, tipus, osszeg, partnerSzamlaszam);
                var ujTranzakcio = _transactionService.TranzakcioLetrehozasa(szamlaszam, tipus, osszeg, datum, partnerSzamlaszam);
                _transactionService.TranzakcioHozzaadasa(ujTranzakcio);
                _fileManager.UjTranzakcioHozzaadasaFajlhoz(ujTranzakcio);
                Console.WriteLine($"Tranzakció sikeresen felvéve! (ID: {ujTranzakcio.Id})");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Hiba: {ex.Message}");
            }
            finally
            {
            }
        }

        public void UgyfelSzamlakLekerdezese(int ugyfelId)
        {
            try
            {
                var szamlak = _accountService.UgyfelSzamlai(ugyfelId);
                Console.WriteLine($"\nÜgyfél számlái (ID: {ugyfelId}):");
                foreach (var szamla in szamlak)
                {
                    Console.WriteLine($"Számlaszám: {szamla.Szamlaszam}, Egyenleg: {szamla.AktualisEgyenleg:C}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Hiba: {ex.Message}");
            }
            finally
            {
            }
        }

        public void SzamlaTranzakciokLekerdezese(string szamlaszam)
        {
            try
            {
                var tranzakciok = _transactionService.SzamlaTranzakcioi(szamlaszam);
                Console.WriteLine($"\nSzámla tranzakciói ({szamlaszam}):");
                foreach (var tranzakcio in tranzakciok)
                {
                    Console.WriteLine($"{tranzakcio.Datum:yyyy-MM-dd} - {tranzakcio.Tipus} - {tranzakcio.Osszeg:C}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Hiba: {ex.Message}");
            }
            finally
            {
            }
        }

        public void NegativEgyenleguSzamlakListazasa()
        {
            try
            {
                var negativSzamlak = _accountService.NegativEgyenleguSzamlak();
                Console.WriteLine("\nNegatív egyenlegű számlák:");
                foreach (var szamla in negativSzamlak)
                {
                    Console.WriteLine($"Számlaszám: {szamla.Szamlaszam}, Egyenleg: {szamla.AktualisEgyenleg:C}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Hiba: {ex.Message}");
            }
            finally
            {
            }
        }

        public void TranzakciokSzurese(string tipus)
        {
            try
            {
                var tranzakciok = _transactionService.TranzakciokSzurese(tipus);
                if (tranzakciok.Count == 0 && tipus != "napi" && tipus != "heti" && tipus != "havi")
                {
                    Console.WriteLine("Érvénytelen szűrési típus! (napi/heti/havi)");
                    return;
                }
                Console.WriteLine($"\n{tipus.ToUpper()} tranzakciók:");
                foreach (var tranzakcio in tranzakciok)
                {
                    Console.WriteLine($"{tranzakcio.Datum:yyyy-MM-dd} - {tranzakcio.Tipus} - {tranzakcio.Osszeg:C}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Hiba: {ex.Message}");
            }
            finally
            {
            }
        }

        public int ElsoUgyfelId()
        {
            try
            {
                if (_ugyfelek.Count > 0)
                {
                    return _ugyfelek[0].Id;
                }
                return 0;
            }
            catch (Exception)
            {
                return 0;
            }
            finally
            {
            }
        }

        public void UgyfelSzamlakLekerdezeseElsoUgyfelhez()
        {
            try
            {
                int ugyfelId = ElsoUgyfelId();
                if (ugyfelId > 0)
                {
                    UgyfelSzamlakLekerdezese(ugyfelId);
                }
                else
                {
                    Console.WriteLine("Nincs rögzített ügyfél!");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Hiba: {ex.Message}");
            }
            finally
            {
            }
        }

        public void UjSzamlaNyitasaElsoUgyfelhez(string szamlaszam, string szamlatipus, double kezdoEgyenleg, DateTime nyitasDatuma)
        {
            try
            {
                int ugyfelId = ElsoUgyfelId();
                if (ugyfelId > 0)
                {
                    UjSzamlaNyitasa(szamlaszam, ugyfelId, szamlatipus, kezdoEgyenleg, nyitasDatuma);
                }
                else
                {
                    Console.WriteLine("Nincs rögzített ügyfél! Először hozz létre egy ügyfelet!");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Hiba: {ex.Message}");
            }
            finally
            {
            }
        }

        public void TesztelesFuttatasa()
        {
            try
            {
                Console.WriteLine("=== Tesztelés ===");

                Console.WriteLine("\n1. Új ügyfél rögzítése:");
                UjUgyfelRogzitese("GEC IMRE", "ABONY, Fő utca 67", new DateTime(2006, 08, 15), "0612345667");

                Console.WriteLine("\n2. Új számla nyitása:");
                UjSzamlaNyitasaElsoUgyfelhez("12345678-12345678-12345677", "folyószámla", 10000, DateTime.Now);

                Console.WriteLine("\n3. Tranzakció felvitele (befizetés):");
                TranzakcioFelvitele("12345678-12345678-12345677", "befizetés", 5000, DateTime.Now);

                Console.WriteLine("\n4. Ügyfél számláinak lekérdezése:");
                UgyfelSzamlakLekerdezeseElsoUgyfelhez();

                Console.WriteLine("\n5. Számla tranzakcióinak lekérdezése:");
                SzamlaTranzakciokLekerdezese("12345678-12345678-12345677");

                Console.WriteLine("\n6. Negatív egyenlegű számlák:");
                NegativEgyenleguSzamlakListazasa();

                Console.WriteLine("\n7. Tranzakciók szűrése (napi):");
                TranzakciokSzurese("napi");

                Console.WriteLine("\nTesztelés befejezve!");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Hiba a tesztelés során: {ex.Message}");
            }
            finally
            {
            }
        }

        public Customer FindCustomerById(int id)
        {
            return _ugyfelek.FirstOrDefault(u => u.Id == id);
        }

        public Account FindAccountByNumber(string accountNumber)
        {
            if (string.IsNullOrWhiteSpace(accountNumber)) throw new ArgumentException();
            return _szamlak.FirstOrDefault(s => s.Szamlaszam == accountNumber);
        }

        public List<Account> GetOverdrawnAccounts()
        {
            return _accountService.NegativEgyenleguSzamlak();
        }
    }
}
