using System;

namespace BankiSzoftverOOP
{
    public class Transaction
    {
        public int Id { get; set; }
        public string ErintettSzamlaszam { get; set; }
        public string Tipus { get; set; }
        public double Osszeg { get; set; }
        public DateTime Datum { get; set; }
        public string PartnerSzamlaszam { get; set; }

        public Transaction()
        {
        }

        public Transaction(int id, string erintettSzamlaszam, string tipus, double osszeg, DateTime datum, string partnerSzamlaszam = "")
        {
            Id = id;
            ErintettSzamlaszam = erintettSzamlaszam;
            Tipus = tipus;
            Osszeg = osszeg;
            Datum = datum;
            PartnerSzamlaszam = partnerSzamlaszam ?? "";
        }

        public override string ToString()
        {
            return $"{Id};{ErintettSzamlaszam};{Tipus};{Osszeg};{Datum:yyyy-MM-dd};{PartnerSzamlaszam}";
        }

        public static Transaction FromString(string line)
        {
            var parts = line.Split(';');
            return new Transaction
            {
                Id = int.Parse(parts[0]),
                ErintettSzamlaszam = parts[1],
                Tipus = parts[2],
                Osszeg = double.Parse(parts[3]),
                Datum = DateTime.Parse(parts[4]),
                PartnerSzamlaszam = parts.Length > 5 ? parts[5] : ""
            };
        }

        public bool IsValid()
        {
            try
            {
                if (Osszeg < 0) return false;
                if (string.IsNullOrWhiteSpace(ErintettSzamlaszam)) return false;
                if (Tipus == "átutalás" && string.IsNullOrWhiteSpace(PartnerSzamlaszam)) return false;
                return true;
            }
            catch (Exception)
            {
                return false;
            }
            finally
            {
            }
        }

        public double CalculateFee(double minFee = 100)
        {
            try
            {
                double fee = Osszeg * 0.01;
                return fee < minFee ? minFee : fee;
            }
            catch (Exception)
            {
                return minFee;
            }
            finally
            {
            }
        }
    }
}

