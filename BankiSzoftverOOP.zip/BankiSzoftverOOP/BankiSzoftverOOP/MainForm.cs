using System;
using System.Windows.Forms;

namespace BankiSzoftverOOP
{
    public partial class MainForm : Form
    {
        private BankSystem _bankSystem;

        public MainForm()
        {
            InitializeComponent();
            _bankSystem = new BankSystem();
        }

        // Új ügyfél rögzítése gomb eseménykezelő
        private void btnUjUgyfel_Click(object sender, EventArgs e)
        {
            try
            {
                string nev = txtNev.Text;
                string lakcim = txtLakcim.Text;
                DateTime szuletesiDatum = dtpSzuletesiDatum.Value;
                string telefonszam = txtTelefonszam.Text;

                _bankSystem.UjUgyfelRogzitese(nev, lakcim, szuletesiDatum, telefonszam);
                MessageBox.Show("Ügyfél sikeresen rögzítve!", "Siker", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba: {ex.Message}", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Új számla nyitása gomb eseménykezelő
        private void btnUjSzamla_Click(object sender, EventArgs e)
        {
            try
            {
                string szamlaszam = txtSzamlaszam.Text;
                int ugyfelId = int.Parse(txtUgyfelId.Text);
                string szamlatipus = cmbSzamlatipus.Text;
                double kezdoEgyenleg = double.Parse(txtKezdoEgyenleg.Text);
                DateTime nyitasDatuma = dtpNyitasDatuma.Value;

                _bankSystem.UjSzamlaNyitasa(szamlaszam, ugyfelId, szamlatipus, kezdoEgyenleg, nyitasDatuma);
                MessageBox.Show("Számla sikeresen nyitva!", "Siker", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba: {ex.Message}", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Tranzakció felvitele gomb eseménykezelő
        private void btnTranzakcio_Click(object sender, EventArgs e)
        {
            try
            {
                string szamlaszam = txtTranzakcioSzamlaszam.Text;
                string tipus = cmbTranzakcioTipus.Text;
                double osszeg = double.Parse(txtTranzakcioOsszeg.Text);
                DateTime datum = dtpTranzakcioDatum.Value;
                string partnerSzamlaszam = txtPartnerSzamlaszam.Text;

                _bankSystem.TranzakcioFelvitele(szamlaszam, tipus, osszeg, datum, partnerSzamlaszam);
                MessageBox.Show("Tranzakció sikeresen felvéve!", "Siker", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba: {ex.Message}", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Ügyfél számláinak lekérdezése gomb eseménykezelő
        private void btnUgyfelSzamlak_Click(object sender, EventArgs e)
        {
            try
            {
                int ugyfelId = int.Parse(txtLekerdezesUgyfelId.Text);
                _bankSystem.UgyfelSzamlakLekerdezese(ugyfelId);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba: {ex.Message}", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Számla tranzakcióinak lekérdezése gomb eseménykezelő
        private void btnSzamlaTranzakciok_Click(object sender, EventArgs e)
        {
            try
            {
                string szamlaszam = txtLekerdezesSzamlaszam.Text;
                _bankSystem.SzamlaTranzakciokLekerdezese(szamlaszam);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba: {ex.Message}", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Negatív egyenlegű számlák listázása gomb eseménykezelő
        private void btnNegativSzamlak_Click(object sender, EventArgs e)
        {
            try
            {
                _bankSystem.NegativEgyenleguSzamlakListazasa();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba: {ex.Message}", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Tranzakciók szűrése gomb eseménykezelő
        private void btnTranzakciokSzurese_Click(object sender, EventArgs e)
        {
            try
            {
                string tipus = cmbSzuresTipus.Text;
                _bankSystem.TranzakciokSzurese(tipus);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba: {ex.Message}", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
