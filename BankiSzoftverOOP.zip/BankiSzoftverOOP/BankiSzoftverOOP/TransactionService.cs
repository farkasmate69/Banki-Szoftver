using System;
using System.Collections.Generic;
using System.Linq;

namespace BankiSzoftverOOP
{
    public class TransactionService
    {
        private List<Transaction> _tranzakciok;
        private List<Account> _szamlak;

        public TransactionService(List<Transaction> tranzakciok, List<Account> szamlak)
        {
            _tranzakciok = tranzakciok;
            _szamlak = szamlak;
        }

        public int KovetkezoId()
        {
            try
            {
                if (_tranzakciok.Count == 0)
                {
                    return 1;
                }
                return _tranzakciok.Max(t => t.Id) + 1;
            }
            catch (Exception)
            {
                return 1;
            }
            finally
            {
            }
        }

        public Account SzamlaKeresese(string szamlaszam)
        {
            try
            {
                return _szamlak.FirstOrDefault(s => s.Szamlaszam == szamlaszam);
            }
            catch (Exception)
            {
                return null;
            }
            finally
            {
            }
        }

        public void EgyenlegFrissitese(string szamlaszam, string tipus, double osszeg, string partnerSzamlaszam = "")
        {
            try
            {
                var szamla = SzamlaKeresese(szamlaszam);
                if (szamla == null)
                {
                    throw new Exception("A számla nem található!");
                }

                if (tipus == "befizetés")
                {
                    szamla.AktualisEgyenleg += osszeg;
                }
                else if (tipus == "készpénzfelvétel")
                {
                    szamla.AktualisEgyenleg -= osszeg;
                }
                else if (tipus == "átutalás")
                {
                    var partnerSzamla = SzamlaKeresese(partnerSzamlaszam);
                    if (partnerSzamla == null)
                    {
                        throw new Exception("A partner számla nem található!");
                    }
                    szamla.AktualisEgyenleg -= osszeg;
                    partnerSzamla.AktualisEgyenleg += osszeg;
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Hiba az egyenleg frissítésekor: {ex.Message}");
            }
            finally
            {
            }
        }

        public Transaction TranzakcioLetrehozasa(string szamlaszam, string tipus, double osszeg, DateTime datum, string partnerSzamlaszam = "")
        {
            try
            {
                int ujId = KovetkezoId();
                return new Transaction(ujId, szamlaszam, tipus, osszeg, datum, partnerSzamlaszam);
            }
            catch (Exception ex)
            {
                throw new Exception($"Hiba a tranzakció létrehozásakor: {ex.Message}");
            }
            finally
            {
            }
        }

        public void TranzakcioHozzaadasa(Transaction tranzakcio)
        {
            try
            {
                _tranzakciok.Add(tranzakcio);
            }
            catch (Exception ex)
            {
                throw new Exception($"Hiba a tranzakció hozzáadásakor: {ex.Message}");
            }
            finally
            {
            }
        }

        public List<Transaction> SzamlaTranzakcioi(string szamlaszam)
        {
            try
            {
                return _tranzakciok.Where(t => t.ErintettSzamlaszam == szamlaszam).ToList();
            }
            catch (Exception)
            {
                return new List<Transaction>();
            }
            finally
            {
            }
        }

        public List<Transaction> TranzakciokSzurese(string tipus)
        {
            try
            {
                DateTime kezdoDatum;
                DateTime vegsoDatum;

                if (tipus == "napi")
                {
                    kezdoDatum = DateTime.Today;
                    vegsoDatum = DateTime.Today.AddDays(1);
                }
                else if (tipus == "heti")
                {
                    kezdoDatum = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek);
                    vegsoDatum = kezdoDatum.AddDays(7);
                }
                else if (tipus == "havi")
                {
                    kezdoDatum = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
                    vegsoDatum = kezdoDatum.AddMonths(1);
                }
                else
                {
                    return new List<Transaction>();
                }

                return _tranzakciok
                    .Where(t => t.Datum >= kezdoDatum && t.Datum < vegsoDatum)
                    .ToList();
            }
            catch (Exception)
            {
                return new List<Transaction>();
            }
            finally
            {
            }
        }
    }
}
