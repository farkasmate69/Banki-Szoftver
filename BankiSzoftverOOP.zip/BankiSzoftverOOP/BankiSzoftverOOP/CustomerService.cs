using System;
using System.Collections.Generic;
using System.Linq;

namespace BankiSzoftverOOP
{
    public class CustomerService
    {
        private List<Customer> _ugyfelek;

        public CustomerService(List<Customer> ugyfelek)
        {
            _ugyfelek = ugyfelek;
        }

        public int KovetkezoId()
        {
            try
            {
                if (_ugyfelek.Count == 0)
                {
                    return 1;
                }
                return _ugyfelek.Max(u => u.Id) + 1;
            }
            catch (Exception)
            {
                return 1;
            }
            finally
            {
            }
        }

        public bool UgyfelLetezik(int id)
        {
            try
            {
                return _ugyfelek.Any(u => u.Id == id);
            }
            catch (Exception)
            {
                return false;
            }
            finally
            {
            }
        }

        public Customer UgyfelLetrehozasa(string nev, string lakcim, DateTime szuletesiDatum, string telefonszam)
        {
            try
            {
                int ujId = KovetkezoId();
                return new Customer(ujId, nev, lakcim, szuletesiDatum, telefonszam);
            }
            catch (Exception ex)
            {
                throw new Exception($"Hiba az ügyfél létrehozásakor: {ex.Message}");
            }
            finally
            {
            }
        }

        public void UgyfelHozzaadasa(Customer ugyfel)
        {
            try
            {
                _ugyfelek.Add(ugyfel);
            }
            catch (Exception ex)
            {
                throw new Exception($"Hiba az ügyfél hozzáadásakor: {ex.Message}");
            }
            finally
            {
            }
        }
    }
}
