using System;
using System.Collections.Generic;
using System.Linq;

namespace BankiSzoftverOOP
{
    public class AccountService
    {
        private List<Account> _szamlak;
        private List<Customer> _ugyfelek;

        public AccountService(List<Account> szamlak, List<Customer> ugyfelek)
        {
            _szamlak = szamlak;
            _ugyfelek = ugyfelek;
        }

        public bool SzamlaLetezik(string szamlaszam)
        {
            try
            {
                return _szamlak.Any(s => s.Szamlaszam == szamlaszam);
            }
            catch (Exception)
            {
                return false;
            }
            finally
            {
            }
        }

        public bool UgyfelLetezik(int ugyfelId)
        {
            try
            {
                return _ugyfelek.Any(u => u.Id == ugyfelId);
            }
            catch (Exception)
            {
                return false;
            }
            finally
            {
            }
        }

        public Account SzamlaLetrehozasa(string szamlaszam, int ugyfelId, string szamlatipus, double kezdoEgyenleg, DateTime nyitasDatuma)
        {
            try
            {
                return new Account(szamlaszam, ugyfelId, szamlatipus, kezdoEgyenleg, nyitasDatuma);
            }
            catch (Exception ex)
            {
                throw new Exception($"Hiba a számla létrehozásakor: {ex.Message}");
            }
            finally
            {
            }
        }

        public void SzamlaHozzaadasa(Account szamla)
        {
            try
            {
                _szamlak.Add(szamla);
            }
            catch (Exception ex)
            {
                throw new Exception($"Hiba a számla hozzáadásakor: {ex.Message}");
            }
            finally
            {
            }
        }

        public Account SzamlaKeresese(string szamlaszam)
        {
            try
            {
                return _szamlak.FirstOrDefault(s => s.Szamlaszam == szamlaszam);
            }
            catch (Exception)
            {
                return null;
            }
            finally
            {
            }
        }

        public List<Account> UgyfelSzamlai(int ugyfelId)
        {
            try
            {
                return _szamlak.Where(s => s.UgyfelId == ugyfelId).ToList();
            }
            catch (Exception)
            {
                return new List<Account>();
            }
            finally
            {
            }
        }

        public List<Account> NegativEgyenleguSzamlak()
        {
            try
            {
                return _szamlak.Where(s => s.AktualisEgyenleg < 0).ToList();
            }
            catch (Exception)
            {
                return new List<Account>();
            }
            finally
            {
            }
        }
    }
}
