﻿using System;

namespace BankiSzoftverOOP
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var bankSystem = new BankSystem();
            bankSystem.TesztelesFuttatasa();
            Console.ReadKey();
        }
    }
}
